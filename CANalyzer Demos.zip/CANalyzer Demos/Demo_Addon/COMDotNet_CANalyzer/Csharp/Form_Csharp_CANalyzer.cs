﻿using System;
using System.Windows.Forms;
using System.IO;

namespace COM_Csharp_CANalyzer_Demo
{
    public partial class Form_Csharp_CANalyzer : Form
    {
        #region Declarations
        // Literals
        private const String mRelativeConfigPath = @"..\..\..\COM.Net\COM.Net.cfg";
        // Fields
        private String mAbsoluteConfigPath;
        private ToolTip mConfigDirToolTip = new ToolTip();
        private bool mCANalyzerInstanceRunning;
        // Delegates
        private delegate void DelSafeInvocation();
        private delegate void DelSafeInvocationWithParam(String sysvarName, object value);
        // CANalyzer objects
        private CANalyzer.Application mCANalyzerApp;
        private CANalyzer.Measurement mCANalyzerMeasurement;
        // CANalyzer CAPL functions
        private CANalyzer.CAPLFunction mCANalyzerMultiply;
        // CANalyzer system variables
        private CANalyzer.Variable mCANalyzerSysVar1;
        private CANalyzer.Variable mCANalyzerSysVar2;
        // CANalyzer signals        
        private CANalyzer.Signal mCANalyzerEngineStatus;
        private CANalyzer.Signal mCANalyzerEngineSpeed;
        private CANalyzer.Signal mCANalyzerEngineTemp;
        #endregion

        #region Construction & Initialization
        public Form_Csharp_CANalyzer()
        {
            InitializeComponent();

            // Check if the necessary configuration is at the correct location.
            PrepareOpenConfiguration();                        
        }             
        #endregion

        #region Opening Tasks
        /// <summary>
        /// Shows the expected directory of the related configuration file and checks if it's located there.
        /// </summary>
        private void PrepareOpenConfiguration()
        {
            // Creates an absolute path out of the provided relative path.
            mAbsoluteConfigPath = Path.GetFullPath(mRelativeConfigPath);

            mTextboxConfigDir.Text = mAbsoluteConfigPath;

            // Sets the selection after the last character in the textbox.
            mTextboxConfigDir.SelectionStart = mTextboxConfigDir.Text.Length;

            if (File.Exists(mAbsoluteConfigPath))
            {
                mLabelDirCheck.Text = Properties.Resources.ConfigFileFound;
                mButtonOpenConfiguration.Enabled = true;
            }
            else
            {
                mLabelDirCheck.Text = Properties.Resources.ConfigFileNotFound;
            }
        }

        /// <summary>
        /// Occurs when a configuration was successfully opened.
        /// </summary>
        private void ConfigurationOpened()
        {
            try
            {
                // Assign system variables from namespaces.
                CANalyzer.System CANalyzerSystem = (CANalyzer.System)mCANalyzerApp.System;
                CANalyzer.Namespaces CANalyzerNamespaces = (CANalyzer.Namespaces)CANalyzerSystem.Namespaces;
                CANalyzer.Namespace CANalyzerNamespaceGeneral = (CANalyzer.Namespace)CANalyzerNamespaces["General"];
                CANalyzer.Variables CANalyzerVariablesGeneral = (CANalyzer.Variables)CANalyzerNamespaceGeneral.Variables;
                mCANalyzerSysVar1 = (CANalyzer.Variable)CANalyzerVariablesGeneral["SysVar1"];
                mCANalyzerSysVar2 = (CANalyzer.Variable)CANalyzerVariablesGeneral["SysVar2"];

                // Assign signals.
                CANalyzer.Bus CANalyzerBus = (CANalyzer.Bus)mCANalyzerApp.get_Bus("CAN");
                mCANalyzerEngineStatus = (CANalyzer.Signal)CANalyzerBus.GetSignal(1, "EngineData", "EngineStatus");
                mCANalyzerEngineSpeed = (CANalyzer.Signal)CANalyzerBus.GetSignal(1, "EngineData", "EngineSpeed");
                mCANalyzerEngineTemp = (CANalyzer.Signal)CANalyzerBus.GetSignal(1, "EngineData", "EngineTemp");
            }
            catch (System.Exception)
            {
                MessageBox.Show("Possible cause: Wrong namespace names, bus name, system variable names or signal names in source code or configuration.",
                    "Error while assigning system variables and signals", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            // Enables the start/stop measurement button.
            mGroupboxConfigSettings.Enabled = false;
            mGroupboxMeasurementControl.Enabled = true;

            mButtonStartStop.Focus();

            if (mCANalyzerApp != null)
            {
                // Wire OnQuit event handler.
                mCANalyzerApp.OnQuit += new CANalyzer._IApplicationEvents_OnQuitEventHandler(CANalyzerQuit);
            }

            if (mCANalyzerMeasurement != null)
            {
                // Create on event handlers.
                mCANalyzerMeasurement.OnInit += new CANalyzer._IMeasurementEvents_OnInitEventHandler(MeasurementInitiated);
                mCANalyzerMeasurement.OnExit += new CANalyzer._IMeasurementEvents_OnExitEventHandler(MeasurementExited);
            }            

            // Indicate that an instance of CANalyzer is running.
            mCANalyzerInstanceRunning = true;
        }
        #endregion

        #region Measurement Init/Exit
        /// <summary>
        /// Occurs when the measurement has been initiated.
        /// </summary>
        private void MeasurementInitiated()
        {
            // Compile CAPL code of the CANalyzer configuration.
            CANalyzer.CAPL CANalyzerCAPL = (CANalyzer.CAPL)mCANalyzerApp.CAPL;
            if (CANalyzerCAPL != null)
            {
                CANalyzerCAPL.Compile(null);
            }

            try
            {
                // Assign CAPL functions.
                mCANalyzerMultiply = (CANalyzer.CAPLFunction)CANalyzerCAPL.GetFunction("Multiply");
            }
            catch (System.Exception)
            {
                MessageBox.Show("Possible cause: Wrong CAPL function name in source code or configuration.",
                    "Error while assigning CAPL functions", MessageBoxButtons.OK, MessageBoxIcon.Error);

                return;
            }

            // Pay attention to thread safety, as the accessed controls were created in the GUI thread!
            DelSafeInvocation safeinvocation = new DelSafeInvocation(MeasurementInitiatedInternal);
            this.Invoke(safeinvocation);

            // Create on event handlers.
            if (mCANalyzerSysVar1 != null)
            {
                mCANalyzerSysVar1.OnChange += new CANalyzer._IVariableEvents_OnChangeEventHandler(SysVar1Changed);
            }

            if (mCANalyzerSysVar2 != null)
            {
                mCANalyzerSysVar2.OnChange += new CANalyzer._IVariableEvents_OnChangeEventHandler(SysVar2Changed);
            }
        }

        /// <summary>
        /// Used for thread safe call to manipulate GUI controls when measurement has been initiated.
        /// </summary>
        private void MeasurementInitiatedInternal()
        {
            mGroupboxCAPLWriteWindowOut.Enabled = true;
            mGroupboxSystemVariables.Enabled = true;
            mGroupboxSignalValues.Enabled = true;
            mButtonStartStop.Text = Properties.Resources.StopMeasurement;
            mLabelMeasurementStatus.Text = Properties.Resources.StatusMeasurementStarted;

            // SysVar1 is chosen by default at startup.
            mProgressbarSysVars.Value = mCANalyzerSysVar1.Value;
            mLabelSysVarsValue.Text = mCANalyzerSysVar1.Value.ToString();
            mLabelSysVarMin.Text = mCANalyzerSysVar1.MinValue.ToString();
            mLabelSysVarMax.Text = mCANalyzerSysVar1.MaxValue.ToString();

            //Activate polling of signal values.
            mTimerPolling.Interval = (int)mNumericupdownCycleTime.Value;
            mTimerPolling.Tick += new EventHandler(PollSignalValues);
            mTimerPolling.Start();
        }

        /// <summary>
        /// Occurs when the measurement has exited.
        /// </summary>
        private void MeasurementExited()
        {
            // Pay attention to thread safety, as the accessed controls were created in the GUI thread!
            DelSafeInvocation safeinvocation = new DelSafeInvocation(MeasurementExitedInternal);
            this.Invoke(safeinvocation);

            // Unregister system variables on event handlers.
            if (mCANalyzerSysVar1 != null)
            {
                mCANalyzerSysVar1.OnChange -= new CANalyzer._IVariableEvents_OnChangeEventHandler(SysVar1Changed);
            }

            if (mCANalyzerSysVar2 != null)
            {
                mCANalyzerSysVar2.OnChange -= new CANalyzer._IVariableEvents_OnChangeEventHandler(SysVar2Changed);
            }
        }

        /// <summary>
        /// Used for thread safe call to manipulate GUI controls when measurement has been exited.
        /// </summary>
        private void MeasurementExitedInternal()
        {
            mGroupboxCAPLWriteWindowOut.Enabled = false;
            mGroupboxSystemVariables.Enabled = false;
            mGroupboxSignalValues.Enabled = false;
            mButtonStartStop.Text = Properties.Resources.StartMeasurement;
            mComboboxSysVars.SelectedIndex = 0;
            mLabelMeasurementStatus.Text = Properties.Resources.StatusMeasurementStopped;
            mLabelEngTempOut.Text = "0";
            mLabelSysVarsValue.Text = "0";
            mTextboxOperand2.Clear();
            mTextboxEngSpeedOut.Text = "0";
            mTextboxEngStatusOut.Text = "Stopped";
            mTextboxOperand2.Clear();
            mTextboxOperand1.Clear();
            mTextboxOperationResult.Clear();
            mProgressbarSysVars.Value = 0;
            mProgressbarEngTempOut.Value = 0;
            mTrackbarSysVars.Value = 0;

            // Deactivate polling of signal values.
            mTimerPolling.Stop();
            mTimerPolling.Tick -= new EventHandler(PollSignalValues);
        }
        #endregion

        #region SysVar and Signal values
        /// <summary>
        ///  Occurs when the polling timer elapses.
        /// </summary>
        private void PollSignalValues(object sender, EventArgs e)
        {
            // Display the current signal values in the output controls.            
            mTextboxEngSpeedOut.Text = mCANalyzerEngineSpeed.Value.ToString();
            mTextboxEngStatusOut.Text = (mCANalyzerEngineStatus.Value == 1) ? "Running" : "Stopped";
            mProgressbarEngTempOut.Value = (int)mCANalyzerEngineTemp.Value;
            mLabelEngTempOut.Text = mCANalyzerEngineTemp.Value.ToString();
        }

        /// <summary>
        /// Occurs when the value of a particular system variable changes.
        /// </summary>
        /// <param name="value">New value</param>
        private void SysVar1Changed(object value)
        {
            // Pay attention to thread safety, as the accessed controls were created in the GUI thread!
            DelSafeInvocationWithParam safeinvocationwithparam = new DelSafeInvocationWithParam(SysVarsChangedInternal);
            this.Invoke(safeinvocationwithparam, "SysVar1", value);
        }

        /// <summary>
        /// Occurs when the value of a particular system variable changes.
        /// </summary>
        /// <param name="value">New value</param>
        private void SysVar2Changed(object value)
        {
            // Pay attention to thread safety, as the accessed controls were created in the GUI thread!
            DelSafeInvocationWithParam safeinvocationwithparam = new DelSafeInvocationWithParam(SysVarsChangedInternal);
            this.Invoke(safeinvocationwithparam, "SysVar2", value);
        }

        /// <summary>
        /// Used for thread safe call to manipulate GUI controls when the value of a system variable has changed.
        /// </summary>
        private void SysVarsChangedInternal(String sysvarName, object value)
        {
            if (mCANalyzerMeasurement != null && mCANalyzerMeasurement.Running)
            {
                // Set new value of the currently selected system variable.
                if (mComboboxSysVars.Text.Equals(sysvarName))
                {
                    mProgressbarSysVars.Value = (int)value;
                    mLabelSysVarsValue.Text = value.ToString();
                }
            }
        }
        #endregion

        #region Closing Tasks
        /// <summary>
        /// Occurs when CANalyzer has quit.
        /// </summary>
        private void CANalyzerQuit()
        {
            // Pay attention to thread safety, as the accessed controls were created in the GUI thread!
            DelSafeInvocation safeinvocation = new DelSafeInvocation(CANalyzerQuitInternal);
            this.Invoke(safeinvocation);

            UnregisterCANalyzerEventHandlers();

            // Indicate that the instance of CANalyzer was closed.
            mCANalyzerInstanceRunning = false;
        }

        /// <summary>
        /// Used for thread safe call to manipulate GUI controls when CANalyzer has quit.
        /// </summary>
        private void CANalyzerQuitInternal()
        {
            // Disables the start/stop measurement button.
            mGroupboxMeasurementControl.Enabled = false;

            // Set the correct caption of the start/stop button.
            mButtonStartStop.Text = Properties.Resources.StartMeasurement;

            // Set the correct caption of the status label.
            mLabelMeasurementStatus.Text = Properties.Resources.StatusMeasurementStopped;

            // Disable the measurement related controls.
            MeasurementExited();
        }

        /// <summary>
        /// Releases all wired event handlers.
        /// </summary>
        private void UnregisterCANalyzerEventHandlers()
        {
            if (mCANalyzerApp != null)
            {
                mCANalyzerApp.OnQuit -= new CANalyzer._IApplicationEvents_OnQuitEventHandler(CANalyzerQuit);
            }

            if (mCANalyzerMeasurement != null)
            {
                mCANalyzerMeasurement.OnInit -= new CANalyzer._IMeasurementEvents_OnInitEventHandler(MeasurementInitiated);
                mCANalyzerMeasurement.OnExit -= new CANalyzer._IMeasurementEvents_OnExitEventHandler(MeasurementExited);
            }
        }
        #endregion

        #region .Net Control EventHandlers
        /// <summary>
        ///  Occurs when the user clicks the button to open the configuration.
        /// </summary>
        private void mButtonOpenConfiguration_Click(object sender, EventArgs e)
        {
            // Init new CANalyzer application.
            mCANalyzerApp = new CANalyzer.Application();

            // Init measurement object.
            mCANalyzerMeasurement = (CANalyzer.Measurement)mCANalyzerApp.Measurement;

            // Stopps a running measurement.
            if (mCANalyzerMeasurement.Running)
            {
                mCANalyzerMeasurement.Stop();
            }
         
            if (mCANalyzerApp != null)
            {                              
                // Open the demo configuration.
                mCANalyzerApp.Open(mAbsoluteConfigPath, true, true);

                // Make sure the configuration was successfully loaded.
                CANalyzer.OpenConfigurationResult ocresult = mCANalyzerApp.Configuration.OpenConfigurationResult;
                if (ocresult.result == 0)
                {
                    ConfigurationOpened();
                }
            }
        }

        /// <summary>
        /// Occurs when the user clicks the button to start or stop a measurement.
        /// </summary>
        private void mButtonStartStop_Click(object sender, EventArgs e)
        {
            if (mCANalyzerMeasurement != null)
            {
                if (mCANalyzerMeasurement.Running)
                {
                    mCANalyzerMeasurement.Stop();
                }
                else
                {
                    mCANalyzerMeasurement.Start();
                }
            }
        }

        /// <summary>
        /// Occurs when the user wants to calculate the multiplication result.
        /// </summary>
        private void mButtonCalculate_Click(object sender, EventArgs e)
        {
            // Call "Multiply" CAPL function and pass parameters, also get return value.
            if (mCANalyzerMultiply != null)
            {
                int operand1, operand2;
                Int32.TryParse(mTextboxOperand1.Text, out operand1);
                Int32.TryParse(mTextboxOperand2.Text, out operand2);

                // Return from a CAPL function works in evaluation branch of measurement set up only.
                int result = (int)mCANalyzerMultiply.Call(operand1, operand2);

                mTextboxOperationResult.Text = result.ToString();
            }
        }

        /// <summary>
        /// Occurs when the mouse pointer hovers over the textbox.
        /// </summary>
        private void mTextboxConfigDir_MouseHover(object sender, EventArgs e)
        {
            // Show tooltip with the absolute configuration path.
            mConfigDirToolTip.Show(mAbsoluteConfigPath, mTextboxConfigDir);            
        }  

        /// <summary>
        /// Occurs when the selection of the combobox has changed.
        /// </summary>
        private void mComboboxSysVars_SelectedIndexChanged(object sender, EventArgs e)
        {
            // Sets the content of controls depending on the selected entry.
            switch (mComboboxSysVars.Text)
            {
                case "SysVar1":
                    mProgressbarSysVars.Value = mCANalyzerSysVar1.Value;
                    mLabelSysVarsValue.Text = mCANalyzerSysVar1.Value.ToString();
                    mLabelSysVarMin.Text = mCANalyzerSysVar1.MinValue.ToString();
                    mLabelSysVarMax.Text = mCANalyzerSysVar1.MaxValue.ToString();

                    break;

                case "SysVar2":
                    mProgressbarSysVars.Value = mCANalyzerSysVar2.Value;
                    mLabelSysVarsValue.Text = mCANalyzerSysVar2.Value.ToString();
                    mLabelSysVarMin.Text = mCANalyzerSysVar2.MinValue.ToString();
                    mLabelSysVarMax.Text = mCANalyzerSysVar2.MaxValue.ToString();

                    break;

                default:
                    break;
            }

            mTrackbarSysVars.Value = 0;
        }

        /// <summary>
        /// Occurs when the slider of the trackbar is scrolled.
        /// </summary>
        private void mTrackbarSysVars_Scroll(object sender, EventArgs e)
        {
            // Communicates new SysVarX value to CANalyzer.
            switch (mComboboxSysVars.Text)
            {
                case "SysVar1":
                    mCANalyzerSysVar1.Value = mTrackbarSysVars.Value;

                    break;

                case "SysVar2":
                    mCANalyzerSysVar2.Value = mTrackbarSysVars.Value;

                    break;

                default:
                    break;
            }                       
        }

        /// <summary>
        /// Occurs when the update cycle time is intended to be changed.
        /// </summary>
        private void mNumericupdownCycleTime_ValueChanged(object sender, EventArgs e)
        {
            // Set a new update cycle time.
            mTimerPolling.Interval = (int)mNumericupdownCycleTime.Value;
        }

        /// <summary>
        /// Occurs when the form is closing.
        /// </summary>
        private void Form_Csharp_CANalyzer_FormClosing(object sender, FormClosingEventArgs e)
        {
            UnregisterCANalyzerEventHandlers();

            // If an instance of CANalyzer is running and a measurement is running assure that it is stopped before the demo closes.
            if (mCANalyzerInstanceRunning && mCANalyzerMeasurement != null && mCANalyzerMeasurement.Running)
            {
                mCANalyzerMeasurement.Stop();
            }                        
        }        
        #endregion
    }
}