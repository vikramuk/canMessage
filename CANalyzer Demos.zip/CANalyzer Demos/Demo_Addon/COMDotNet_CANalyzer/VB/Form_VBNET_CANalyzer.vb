﻿Imports CANalyzer
Imports System.IO

Public Class Form_VBNET_CANalyzer

#Region "Declarations"

    ' Literals
    Private Const mRelativeConfigPath As String = "..\..\..\COM.Net\COM.Net.cfg"
    ' Fields
    Private mAbsoluteConfigPath As String
    Private mConfigDirToolTip As ToolTip = New ToolTip
    Private mCANalyzerInstanceRunning As Boolean
    ' Delegates
    Private Delegate Sub DelSafeInvocation()
    Private Delegate Sub DelSafeInvocationWithParam(sysvarName As String, value As Object)
    ' CANalyzer objects
    Private WithEvents mCANalyzerApp As Application
    Private WithEvents mCANalyzerMeasurement As Measurement
    ' CANalyzer CAPL functions
    Private mCANalyzerMultiply As CAPLFunction
    ' CANalyzer system variables    
    Private WithEvents mCANalyzerSysVar1 As Variable
    Private WithEvents mCANalyzerSysVar2 As Variable
    ' CANalyzer signals    
    Private mCANalyzerEngineStatus As Signal
    Private mCANalyzerEngineSpeed As Signal
    Private mCANalyzerEngineTemp As Signal
#End Region

#Region "Construction & Initialization"

    Public Sub New()

        ' This call is required by the designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

        ' Check if the necessary configuration is at the correct location.
        PrepareOpenConfiguration()
    End Sub
#End Region

#Region "Opening Tasks"

    ' Shows the expected directory of the related configuration file and checks if it's located there.
    Private Sub PrepareOpenConfiguration()

        ' Creates an absolute path out of the provided relative path.
        mAbsoluteConfigPath = Path.GetFullPath(mRelativeConfigPath)

        mTextboxConfigDir.Text = mAbsoluteConfigPath

        ' Sets the selection after the last character in the textbox.
        mTextboxConfigDir.SelectionStart = mTextboxConfigDir.Text.Length

        If File.Exists(mAbsoluteConfigPath) Then
            mLabelDirCheck.Text = My.Resources.ConfigFileFound()
            mButtonOpenConfiguration.Enabled = True
        Else
            mLabelDirCheck.Text = My.Resources.ConfigFileNotFound()
        End If
    End Sub

    ' Occurs when a configuration was successfully opened.
    Private Sub ConfigurationOpened()

        Try
            ' Assign system variables from namespaces.            
            Dim CANalyzerNamespaceGeneral As CANalyzer.Namespace = mCANalyzerApp.System.Namespaces("General")
            mCANalyzerSysVar1 = CANalyzerNamespaceGeneral.Variables("SysVar1")
            mCANalyzerSysVar2 = CANalyzerNamespaceGeneral.Variables("SysVar2")

            ' Assign signals.
            Dim CANalyzerBus As Bus = mCANalyzerApp.Bus("CAN")
            mCANalyzerEngineStatus = CANalyzerBus.GetSignal(1, "EngineData", "EngineStatus")
            mCANalyzerEngineSpeed = CANalyzerBus.GetSignal(1, "EngineData", "EngineSpeed")
            mCANalyzerEngineTemp = CANalyzerBus.GetSignal(1, "EngineData", "EngineTemp")
        Catch ex As Exception
            MessageBox.Show("Possible cause: Wrong namespace names, bus name, system variable names or signal names in source code or configuration.",
                            "Error while assigning system variables and signals", MessageBoxButtons.OK, MessageBoxIcon.Hand)

            Return
        End Try

        ' Enables the start/stop measurement button.
        mGroupboxConfigSettings.Enabled = False
        mGroupboxMeasurementControl.Enabled = True

        mButtonStartStop.Focus()

        If (Not mCANalyzerApp Is Nothing) Then
            ' Wire OnQuit event handler.
            AddHandler mCANalyzerApp.OnQuit, AddressOf CANalyzerQuit
        End If

        If (Not mCANalyzerMeasurement Is Nothing) Then
            ' Create on event handlers.
            AddHandler mCANalyzerMeasurement.OnInit, AddressOf MeasurementInitiated
            AddHandler mCANalyzerMeasurement.OnExit, AddressOf MeasurementExited
        End If

        ' Indicate that an instance of CANalyzer is running.
        mCANalyzerInstanceRunning = True
    End Sub
#End Region

#Region "Measurement Init/Exit"

    ' Occurs when the measurement has been initiated.
    Private Sub MeasurementInitiated()

        ' Compile CAPL code of the CANalyzer configuration.
        Dim CANalyzerCAPL As CANalyzer.CAPL = mCANalyzerApp.CAPL
        If (Not CANalyzerCAPL Is Nothing) Then
            CANalyzerCAPL.Compile(Nothing)
        End If

        Try
            ' Assign CAPL functions.
            mCANalyzerMultiply = CANalyzerCAPL.GetFunction("Multiply")
        Catch ex As Exception
            MessageBox.Show("Possible cause: Wrong CAPL function name in source code or configuration.",
                            "Error while assigning CAPL functions", MessageBoxButtons.OK, MessageBoxIcon.Hand)

            Return
        End Try

        ' Pay attention to thread safety, as the accessed controls were created in the GUI thread!
        Dim safeinvocation As DelSafeInvocation = New DelSafeInvocation(AddressOf MeasurementInitiatedInternal)
        Invoke(safeinvocation)

        ' Create system variable on event handlers.
        If (Not mCANalyzerSysVar1 Is Nothing) Then
            AddHandler mCANalyzerSysVar1.OnChange, AddressOf SysVar1Changed
        End If

        If (Not mCANalyzerSysVar2 Is Nothing) Then
            AddHandler mCANalyzerSysVar2.OnChange, AddressOf SysVar2Changed
        End If
    End Sub

    ' Used for thread safe call to manipulate GUI controls when measurement has been initiated.
    Private Sub MeasurementInitiatedInternal()

        mGroupboxCAPLWriteWindowOut.Enabled = True
        mGroupboxSystemVariables.Enabled = True
        mGroupboxSignalValues.Enabled = True
        mButtonStartStop.Text = My.Resources.StopMeasurement
        mLabelMeasurementStatus.Text = My.Resources.StatusMeasurementStarted

        ' SysVar1 is chosen by default at startup.
        mProgressbarSysVars.Value = mCANalyzerSysVar1.Value
        mLabelSysVarsValue.Text = mCANalyzerSysVar1.Value.ToString
        mLabelSysVarMin.Text = mCANalyzerSysVar1.MinValue.ToString
        mLabelSysVarMax.Text = mCANalyzerSysVar1.MaxValue.ToString

        ' Activate polling of signal values.
        mTimerPolling.Interval = mNumericupdownCycleTime.Value
        AddHandler mTimerPolling.Tick, AddressOf PollSignalValues
        mTimerPolling.Start()
    End Sub

    ' Occurs when the measurement has exited.
    Private Sub MeasurementExited()

        ' Pay attention to thread safety, as the accessed controls were created in the GUI thread!
        Dim safeinvocation As DelSafeInvocation = New DelSafeInvocation(AddressOf MeasurementExitedInternal)
        Invoke(safeinvocation)

        ' Unregister system variables on event handlers.
        If (Not mCANalyzerSysVar1 Is Nothing) Then
            RemoveHandler mCANalyzerSysVar1.OnChange, AddressOf SysVar1Changed
        End If

        If (Not mCANalyzerSysVar2 Is Nothing) Then
            RemoveHandler mCANalyzerSysVar2.OnChange, AddressOf SysVar2Changed
        End If
    End Sub

    ' Used for thread safe call to manipulate GUI controls when measurement has been exited.
    Private Sub MeasurementExitedInternal()

        mGroupboxCAPLWriteWindowOut.Enabled = False
        mGroupboxSystemVariables.Enabled = False
        mGroupboxSignalValues.Enabled = False
        mButtonStartStop.Text = My.Resources.StartMeasurement
        mComboboxSysVars.SelectedIndex = 0
        mLabelMeasurementStatus.Text = My.Resources.StatusMeasurementStopped
        mLabelEngTempOut.Text = "0"
        mLabelSysVarsValue.Text = "0"
        mTextboxOperand2.Clear()
        mTextboxEngSpeedOut.Text = "0"
        mTextboxEngStatusOut.Text = "Stopped"
        mTextboxOperand2.Clear()
        mTextboxOperand1.Clear()
        mTextboxOperationResult.Clear()
        mProgressbarSysVars.Value = 0
        mProgressbarEngTempOut.Value = 0
        mTrackbarSysVars.Value = 0

        ' Deactivate polling of signal values. 
        mTimerPolling.Stop()
        RemoveHandler mTimerPolling.Tick, AddressOf PollSignalValues
    End Sub
#End Region

#Region "SysVar and Signal values"

    ' Occurs when the polling timer elapses.
    Private Sub PollSignalValues(ByVal sender As Object, ByVal e As EventArgs)

        ' Display the current signal values in the output controls.            
        mTextboxEngSpeedOut.Text = mCANalyzerEngineSpeed.Value.ToString
        mTextboxEngStatusOut.Text = If((mCANalyzerEngineStatus.Value = 1), "Running", "Stopped")
        mProgressbarEngTempOut.Value = mCANalyzerEngineTemp.Value
        mLabelEngTempOut.Text = mCANalyzerEngineTemp.Value.ToString
    End Sub

    ' Occurs when the value of a particular system variable changes.
    Private Sub SysVar1Changed(ByVal value As Object)

        ' Pay attention to thread safety, as the accessed controls were created in the GUI thread!
        Dim safeinvocationwithparam As DelSafeInvocationWithParam = New DelSafeInvocationWithParam(AddressOf SysVarsChangedInternal)
        Invoke(safeinvocationwithparam, "SysVar1", value)
    End Sub

    ' Occurs when the value of a particular system variable changes.
    Private Sub SysVar2Changed(ByVal value As Object)

        ' Pay attention to thread safety, as the accessed controls were created in the GUI thread!
        Dim safeinvocationwithparam As DelSafeInvocationWithParam = New DelSafeInvocationWithParam(AddressOf SysVarsChangedInternal)
        Invoke(safeinvocationwithparam, "SysVar2", value)
    End Sub

    ' Used for thread safe call to manipulate GUI controls when the value of a system variable has changed.
    Private Sub SysVarsChangedInternal(sysvarName As String, value As Object)

        If (((Not mCANalyzerMeasurement Is Nothing) AndAlso mCANalyzerMeasurement.Running)) Then

            ' Set new value of the currently selected system variable.
            If (mComboboxSysVars.Text.Equals(sysvarName)) Then
                mProgressbarSysVars.Value = value
                mLabelSysVarsValue.Text = value.ToString
            End If
        End If
    End Sub
#End Region

#Region "Closing Tasks"

    ' Occurs when CANalyzer has quit.
    Private Sub CANalyzerQuit()

        ' Pay attention to thread safety, as the accessed controls were created in the GUI thread!
        Dim safeinvocation As DelSafeInvocation = New DelSafeInvocation(AddressOf CANalyzerQuitInternal)
        Invoke(safeinvocation)

        UnregisterCANalyzerEventHandlers()

        ' Indicate that the instance of CANalyzer was closed.
        mCANalyzerInstanceRunning = False
    End Sub

    ' Used for thread safe call to manipulate GUI controls when CANalyzer has quit.
    Private Sub CANalyzerQuitInternal()

        ' Disables the start/stop measurement button.
        mGroupboxMeasurementControl.Enabled = False

        ' Set the correct caption of the start/stop button.
        mButtonStartStop.Text = My.Resources.StartMeasurement

        ' Set the correct caption of the status label.
        mLabelMeasurementStatus.Text = My.Resources.StatusMeasurementStopped

        ' Disable the measurement related controls.
        MeasurementExited()
    End Sub

    ' Releases all wired event handlers.
    Private Sub UnregisterCANalyzerEventHandlers()

        If (Not mCANalyzerApp Is Nothing) Then
            RemoveHandler mCANalyzerApp.OnQuit, AddressOf CANalyzerQuit
        End If

        If (Not mCANalyzerMeasurement Is Nothing) Then
            RemoveHandler mCANalyzerMeasurement.OnInit, AddressOf MeasurementInitiated
            RemoveHandler mCANalyzerMeasurement.OnExit, AddressOf MeasurementExited
        End If
    End Sub
#End Region

#Region ".Net Control EventHandlers"

    ' Occurs when the user clicks the button to open the configuration.
    Private Sub mButtonOpenConfiguration_Click(sender As System.Object, e As System.EventArgs) Handles mButtonOpenConfiguration.Click

        ' Init new CANalyzer application.
        mCANalyzerApp = New CANalyzer.Application

        ' Init measurement object.
        mCANalyzerMeasurement = mCANalyzerApp.Measurement

        ' Stopps a running measurement.
        If mCANalyzerMeasurement.Running Then
            mCANalyzerMeasurement.Stop()
        End If

        If (Not mCANalyzerApp Is Nothing) Then

            ' Open the demo configuration.
            mCANalyzerApp.Open(mAbsoluteConfigPath, True, True)

            ' Make sure the configuration was successfully loaded.
            Dim ocresult As CANalyzer.OpenConfigurationResult = mCANalyzerApp.Configuration.OpenConfigurationResult
            If (ocresult.result = 0) Then
                ConfigurationOpened()
            End If
        End If
    End Sub

    ' Occurs when the user clicks the button to start or stop a measurement.
    Private Sub mButtonStartStop_Click(sender As System.Object, e As System.EventArgs) Handles mButtonStartStop.Click

        If (Not mCANalyzerMeasurement Is Nothing) Then
            If mCANalyzerMeasurement.Running Then
                mCANalyzerMeasurement.Stop()
            Else
                mCANalyzerMeasurement.Start()
            End If
        End If
    End Sub

    ' Occurs when the user wants to calculate the multiplication result.
    Private Sub mButtonCalculate_Click(sender As System.Object, e As System.EventArgs) Handles mButtonCalculate.Click

        ' Call "Multiply" CAPL function and pass parameters, also get return value.
        If (Not mCANalyzerMultiply Is Nothing) Then

            Dim operand1 As Integer
            Dim operand2 As Integer
            Dim result As Integer

            Integer.TryParse(mTextboxOperand1.Text, operand1)
            Integer.TryParse(mTextboxOperand2.Text, operand2)

            ' Return from a CAPL function works in evaluation branch of measurement set up only.
            result = mCANalyzerMultiply.Call(operand1, operand2)

            mTextboxOperationResult.Text = result.ToString
        End If
    End Sub

    ' Occurs when the mouse pointer hovers over the textbox.
    Private Sub mTextboxConfigDir_MouseHover(sender As System.Object, e As System.EventArgs) Handles mTextboxConfigDir.MouseHover

        ' Show tooltip with the absolute configuration path.
        mConfigDirToolTip.Show(mAbsoluteConfigPath, mTextboxConfigDir)
    End Sub

    ' Occurs when the selection of the combobox has changed.
    Private Sub mComboboxSysVars_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles mComboboxSysVars.SelectedIndexChanged

        ' Sets the content of controls depending on the selected entry.
        Dim selectedEntry As String = mComboboxSysVars.Text

        If ((Not mCANalyzerSysVar1 Is Nothing) AndAlso (Not mCANalyzerSysVar2 Is Nothing)) Then
            If (selectedEntry = "SysVar1") Then
                mProgressbarSysVars.Value = mCANalyzerSysVar1.Value
                mLabelSysVarsValue.Text = mCANalyzerSysVar1.Value.ToString
                mLabelSysVarMin.Text = mCANalyzerSysVar1.MinValue.ToString
                mLabelSysVarMax.Text = mCANalyzerSysVar1.MaxValue.ToString
            ElseIf (selectedEntry = "SysVar2") Then
                mProgressbarSysVars.Value = mCANalyzerSysVar2.Value
                mLabelSysVarsValue.Text = mCANalyzerSysVar2.Value.ToString
                mLabelSysVarMin.Text = mCANalyzerSysVar2.MinValue.ToString
                mLabelSysVarMax.Text = mCANalyzerSysVar2.MaxValue.ToString
            End If
        End If

        mTrackbarSysVars.Value = 0
    End Sub

    ' Occurs when the slider of the trackbar is scrolled.
    Private Sub mTrackbarSysVars_Scroll(sender As System.Object, e As System.EventArgs) Handles mTrackbarSysVars.Scroll

        Dim selectedEntry As String = mComboboxSysVars.Text

        ' Communicates new SysVarX value to CANalyzer.
        If (selectedEntry = "SysVar1") Then
            mCANalyzerSysVar1.Value = mTrackbarSysVars.Value
        ElseIf (selectedEntry = "SysVar2") Then
            mCANalyzerSysVar2.Value = mTrackbarSysVars.Value
        End If
    End Sub

    ' Occurs when the update cycle time is intended to be changed.
    Private Sub mNumericupdownCycleTime_ValueChanged(sender As System.Object, e As System.EventArgs) Handles mNumericupdownCycleTime.ValueChanged

        ' Set a new update cycle time.
        mTimerPolling.Interval = mNumericupdownCycleTime.Value
    End Sub

    ' Occurs when the form is closing.
    Private Sub Form_VBNET_CANalyzer_FormClosing(sender As System.Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing

        UnregisterCANalyzerEventHandlers()

        ' If an instance of CANalyzer is running and a measurement is running assure that it is stopped before the demo closes.
        If (mCANalyzerInstanceRunning AndAlso (Not mCANalyzerMeasurement Is Nothing) AndAlso mCANalyzerMeasurement.Running) Then
            mCANalyzerMeasurement.Stop()
        End If
    End Sub
#End Region
End Class
