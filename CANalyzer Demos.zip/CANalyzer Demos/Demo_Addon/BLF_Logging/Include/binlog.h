/*----------------------------------------------------------------------------
|
|-----------------------------------------------------------------------------
|               A U T H O R   I D E N T I T Y
|-----------------------------------------------------------------------------
| Initials     Name                      Company
| --------     ---------------------     ------------------------------------
| Sn           Michael Stephan           Vector Informatik GmbH
|-----------------------------------------------------------------------------
|               R E V I S I O N   H I S T O R Y
|-----------------------------------------------------------------------------
| Date         Ver  Author  Description
| ---------    ---  ------  --------------------------------------------------
| 01/04/02     1.0  Sn      Creation
|-----------------------------------------------------------------------------
|               C O P Y R I G H T
|-----------------------------------------------------------------------------
| Copyright (c) 2002 by Vector Informatik GmbH.  All rights reserved.
 ----------------------------------------------------------------------------*/
#if !defined ( BINARY_LOGGING_H )
       #define BINARY_LOGGING_H

#if defined ( _MSC_VER )
  #pragma warning( disable: 4103)
  #pragma pack( push, 8)
#elif defined ( __BORLANDC__ )
  #pragma option push -a8
  #pragma nopushoptwarn
  #pragma nopackwarning
#endif

#include <wtypes.h>

/*----------------------------------------------------------------------------
|
| BL API
|
-----------------------------------------------------------------------------*/

#define BL_MAJOR_NUMBER 3
#define BL_MINOR_NUMBER 9
#define BL_BUILD_NUMBER 9
#define BL_PATCH_NUMBER 0

#if defined ( BINLOG_EXPORTS )
  #define BLAPI( ret)                        ret __stdcall
#else
  #define BLAPI( ret) __declspec( dllimport) ret __stdcall
#endif

/*----------------------------------------------------------------------------
|
| Object type IDs
|
-----------------------------------------------------------------------------*/

#define BL_OBJ_SIGNATURE          0x4A424F4C       /* object signature */

#define BL_OBJ_TYPE_UNKNOWN                0       /* unknown object */
#define BL_OBJ_TYPE_CAN_MESSAGE            1       /* CAN message object */
#define BL_OBJ_TYPE_CAN_ERROR              2       /* CAN error frame object */
#define BL_OBJ_TYPE_CAN_OVERLOAD           3       /* CAN overload frame object */
#define BL_OBJ_TYPE_CAN_STATISTIC          4       /* CAN driver statistics object */
#define BL_OBJ_TYPE_APP_TRIGGER            5       /* application trigger object */
#define BL_OBJ_TYPE_ENV_INTEGER            6       /* environment integer object */
#define BL_OBJ_TYPE_ENV_DOUBLE             7       /* environment double object */
#define BL_OBJ_TYPE_ENV_STRING             8       /* environment string object */
#define BL_OBJ_TYPE_ENV_DATA               9       /* environment data object */
#define BL_OBJ_TYPE_LOG_CONTAINER         10       /* container object */

#define BL_OBJ_TYPE_LIN_MESSAGE           11       /* LIN message object */
#define BL_OBJ_TYPE_LIN_CRC_ERROR         12       /* LIN CRC error object */
#define BL_OBJ_TYPE_LIN_DLC_INFO          13       /* LIN DLC info object */
#define BL_OBJ_TYPE_LIN_RCV_ERROR         14       /* LIN receive error object */
#define BL_OBJ_TYPE_LIN_SND_ERROR         15       /* LIN send error object */
#define BL_OBJ_TYPE_LIN_SLV_TIMEOUT       16       /* LIN slave timeout object */
#define BL_OBJ_TYPE_LIN_SCHED_MODCH       17       /* LIN scheduler mode change object */
#define BL_OBJ_TYPE_LIN_SYN_ERROR         18       /* LIN sync error object */
#define BL_OBJ_TYPE_LIN_BAUDRATE          19       /* LIN baudrate event object */
#define BL_OBJ_TYPE_LIN_SLEEP             20       /* LIN sleep mode event object */
#define BL_OBJ_TYPE_LIN_WAKEUP            21       /* LIN wakeup event object */

#define BL_OBJ_TYPE_MOST_SPY              22       /* MOST spy message object */
#define BL_OBJ_TYPE_MOST_CTRL             23       /* MOST control message object */
#define BL_OBJ_TYPE_MOST_LIGHTLOCK        24       /* MOST light lock object */
#define BL_OBJ_TYPE_MOST_STATISTIC        25       /* MOST statistic object */

#define BL_OBJ_TYPE_reserved_1            26       /* reserved */
#define BL_OBJ_TYPE_reserved_2            27       /* reserved */
#define BL_OBJ_TYPE_reserved_3            28       /* reserved */

#define BL_OBJ_TYPE_FLEXRAY_DATA          29       /* FLEXRAY data object */
#define BL_OBJ_TYPE_FLEXRAY_SYNC          30       /* FLEXRAY sync object */

#define BL_OBJ_TYPE_CAN_DRIVER_ERROR      31       /* CAN driver error object */

#define BL_OBJ_TYPE_MOST_PKT              32       /* MOST Packet */
#define BL_OBJ_TYPE_MOST_PKT2             33       /* MOST Packet including original timestamp */
#define BL_OBJ_TYPE_MOST_HWMODE           34       /* MOST hardware mode event */
#define BL_OBJ_TYPE_MOST_REG              35       /* MOST register data (various chips)*/
#define BL_OBJ_TYPE_MOST_GENREG           36       /* MOST register data (MOST register) */
#define BL_OBJ_TYPE_MOST_NETSTATE         37       /* MOST NetState event */
#define BL_OBJ_TYPE_MOST_DATALOST         38       /* MOST data lost */
#define BL_OBJ_TYPE_MOST_TRIGGER          39       /* MOST trigger */

#define BL_OBJ_TYPE_FLEXRAY_CYCLE         40       /* FLEXRAY V6 start cycle object */
#define BL_OBJ_TYPE_FLEXRAY_MESSAGE       41       /* FLEXRAY V6 message object */

#define BL_OBJ_TYPE_LIN_CHECKSUM_INFO     42       /* LIN checksum info event object */
#define BL_OBJ_TYPE_LIN_SPIKE_EVENT       43       /* LIN spike event object */

#define BL_OBJ_TYPE_CAN_DRIVER_SYNC       44       /* CAN driver hardware sync */

#define BL_OBJ_TYPE_FLEXRAY_STATUS        45       /* FLEXRAY status event object */

#define BL_OBJ_TYPE_GPS_EVENT             46       /* GPS event object */

#define BL_OBJ_TYPE_FR_ERROR              47       /* FLEXRAY error event object */
#define BL_OBJ_TYPE_FR_STATUS             48       /* FLEXRAY status event object */
#define BL_OBJ_TYPE_FR_STARTCYCLE         49       /* FLEXRAY start cycle event object */
#define BL_OBJ_TYPE_FR_RCVMESSAGE         50       /* FLEXRAY receive message event object */

#define BL_OBJ_TYPE_REALTIMECLOCK         51       /* Realtime clock object */
#define BL_OBJ_TYPE_AVAILABLE2            52       /* this object ID is available for the future */
#define BL_OBJ_TYPE_AVAILABLE3            53       /* this object ID is available for the future */

#define BL_OBJ_TYPE_LIN_STATISTIC         54       /* LIN statistic event object */

#define BL_OBJ_TYPE_J1708_MESSAGE         55       /* J1708 message object */
#define BL_OBJ_TYPE_J1708_VIRTUAL_MSG     56       /* J1708 message object with more than 21 data bytes */

#define BL_OBJ_TYPE_LIN_MESSAGE2          57       /* LIN frame object - extended */
#define BL_OBJ_TYPE_LIN_SND_ERROR2        58       /* LIN transmission error object - extended */
#define BL_OBJ_TYPE_LIN_SYN_ERROR2        59       /* LIN sync error object - extended */
#define BL_OBJ_TYPE_LIN_CRC_ERROR2        60       /* LIN checksum error object - extended */
#define BL_OBJ_TYPE_LIN_RCV_ERROR2        61       /* LIN receive error object */
#define BL_OBJ_TYPE_LIN_WAKEUP2           62       /* LIN wakeup event object  - extended */
#define BL_OBJ_TYPE_LIN_SPIKE_EVENT2      63       /* LIN spike event object - extended */
#define BL_OBJ_TYPE_LIN_LONG_DOM_SIG      64       /* LIN long dominant signal object */

#define BL_OBJ_TYPE_APP_TEXT              65       /* text object */

#define BL_OBJ_TYPE_FR_RCVMESSAGE_EX      66       /* FLEXRAY receive message ex event object */

#define BL_OBJ_TYPE_MOST_STATISTICEX      67       /* MOST extended statistic event */
#define BL_OBJ_TYPE_MOST_TXLIGHT          68       /* MOST TxLight event */
#define BL_OBJ_TYPE_MOST_ALLOCTAB         69       /* MOST Allocation table event */
#define BL_OBJ_TYPE_MOST_STRESS           70       /* MOST Stress event */

#define BL_OBJ_TYPE_ETHERNET_FRAME        71       /* Ethernet frame object */

#define BL_OBJ_TYPE_SYS_VARIABLE          72       /* system variable object */

#define BL_OBJ_TYPE_CAN_ERROR_EXT         73       /* CAN error frame object (extended) */
#define BL_OBJ_TYPE_CAN_DRIVER_ERROR_EXT  74       /* CAN driver error object (extended) */

#define BL_OBJ_TYPE_LIN_LONG_DOM_SIG2     75       /* LIN long dominant signal object - extended */

#define BL_OBJ_TYPE_MOST_150_MESSAGE            76   /* MOST150 Control channel message */
#define BL_OBJ_TYPE_MOST_150_PKT                77   /* MOST150 Asynchronous channel message */
#define BL_OBJ_TYPE_MOST_ETHERNET_PKT           78   /* MOST Ethernet channel message */
#define BL_OBJ_TYPE_MOST_150_MESSAGE_FRAGMENT   79   /* Partial transmitted MOST50/150 Control channel message */
#define BL_OBJ_TYPE_MOST_150_PKT_FRAGMENT       80   /* Partial transmitted MOST50/150 data packet on asynchronous channel */
#define BL_OBJ_TYPE_MOST_ETHERNET_PKT_FRAGMENT  81   /* Partial transmitted MOST Ethernet packet on asynchronous channel */
#define BL_OBJ_TYPE_MOST_SYSTEM_EVENT           82   /* Event for various system states on MOST */
#define BL_OBJ_TYPE_MOST_150_ALLOCTAB           83   /* MOST50/150 Allocation table event */
#define BL_OBJ_TYPE_MOST_50_MESSAGE             84   /* MOST50 Control channel message */
#define BL_OBJ_TYPE_MOST_50_PKT                 85   /* MOST50 Asynchronous channel message */

#define BL_OBJ_TYPE_CAN_MESSAGE2          86         /* CAN message object - extended */

#define BL_OBJ_TYPE_LIN_UNEXPECTED_WAKEUP       87
#define BL_OBJ_TYPE_LIN_SHORT_OR_SLOW_RESPONSE  88
#define BL_OBJ_TYPE_LIN_DISTURBANCE_EVENT       89

#define BL_OBJ_TYPE_SERIAL_EVENT                90

#define BL_OBJ_TYPE_OVERRUN_ERROR               91   /* driver overrun event */

#define BL_OBJ_TYPE_EVENT_COMMENT               92

#define BL_OBJ_TYPE_WLAN_FRAME                  93
#define BL_OBJ_TYPE_WLAN_STATISTIC              94

#define BL_OBJ_TYPE_MOST_ECL                    95   /* MOST Electrical Control Line event */

#define BL_OBJ_TYPE_GLOBAL_MARKER               96

#define BL_OBJ_TYPE_AFDX_FRAME                  97
#define BL_OBJ_TYPE_AFDX_STATISTIC              98

#define BL_OBJ_TYPE_KLINE_STATUSEVENT           99   /* E.g. wake-up pattern */

#define BL_OBJ_TYPE_CAN_FD_MESSAGE             100   /*CAN FD message object*/

#define BL_OBJ_TYPE_CAN_FD_MESSAGE_64          101   /*CAN FD message object */

#define BL_OBJ_TYPE_ETHERNET_RX_ERROR          102   /* Ethernet RX error object */
#define BL_OBJ_TYPE_ETHERNET_STATUS            103   /* Ethernet status object */

#define BL_OBJ_TYPE_CAN_FD_ERROR_64          104   /*CAN FD Error Frame object */
/*----------------------------------------------------------------------------
|
| Base object header type definition
|
-----------------------------------------------------------------------------*/

typedef struct VBLObjectHeaderBase_t
{
    DWORD     mSignature;                        /* signature (BL_OBJ_SIGNATURE) */
     WORD     mHeaderSize;                       /* sizeof object header */
     WORD     mHeaderVersion;                    /* header version (1) */
    DWORD     mObjectSize;                       /* object size */
    DWORD     mObjectType;                       /* object type (BL_OBJ_TYPE_XXX) */
} VBLObjectHeaderBase;

/*----------------------------------------------------------------------------
|
| Object flag IDs
|
-----------------------------------------------------------------------------*/

#define BL_OBJ_FLAG_TIME_TEN_MICS     0x00000001 /* 10 micro second timestamp */
#define BL_OBJ_FLAG_TIME_ONE_NANS     0x00000002 /* 1 nano second timestamp */

/*----------------------------------------------------------------------------
|
| Object header type definitions
|
-----------------------------------------------------------------------------*/

typedef struct VBLObjectHeader_t
{
    VBLObjectHeaderBase mBase;                   /* base header object */
    DWORD               mObjectFlags;            /* object flags */
    WORD                mReserved;               /* reserved */
    WORD                mObjectVersion;          /* object specific version */
    ULONGLONG           mObjectTimeStamp;        /* object timestamp */
} VBLObjectHeader;

typedef struct VBLObjectHeader2_t
{
    VBLObjectHeaderBase mBase;                   /* base header object */
    DWORD               mObjectFlags;            /* object flags */
    BYTE                mTimeStampStatus;        /* time stamp status */
    BYTE                mReserved1;              /* reserved */
    WORD                mObjectVersion;          /* object specific version */
    ULONGLONG           mObjectTimeStamp;        /* object timestamp */
    ULONGLONG           mOriginalTimeStamp;      /* original object timestamp */
} VBLObjectHeader2;

/*----------------------------------------------------------------------------
|
| Flags for TimeStampStatus
|
-----------------------------------------------------------------------------*/

#define BL_OBJ_TIMESTAMPSTATUS_FLAG_ORIG   0x01  /* 1: valid orig. timestamp  */
#define BL_OBJ_TIMESTAMPSTATUS_FLAG_SWHW   0x02  /* 1: sw generated ts; 0: hw */
#define BL_OBJ_TIMESTAMPSTATUS_FLAG_USER   0x10  /* protocol specific meaning */

/*----------------------------------------------------------------------------
|
| CAN objects
|
-----------------------------------------------------------------------------*/
/* HINT: Extension of this structure is not allowed! */
typedef struct VBLCANMessage_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mFlags;                      /* CAN dir & rtr */
    BYTE            mDLC;                        /* CAN dlc */
    DWORD           mID;                         /* CAN ID */
    BYTE            mData[8];                    /* CAN data */
} VBLCANMessage;

// CAN dir, rtr, wu & nerr encoded into flags
#define CAN_MSG_DIR( f)          ( BYTE)(   f & 0x0F)
#define CAN_MSG_RTR( f)          ( BYTE)( ( f & 0x80) >> 7)
#define CAN_MSG_WU( f)           ( BYTE)( ( f & 0x40) >> 6)
#define CAN_MSG_NERR( f)         ( BYTE)( ( f & 0x20) >> 5)
#define CAN_MSG_FLAGS( dir, rtr) ( BYTE)( ( ( BYTE)( rtr & 0x01) << 7) | \
                                            ( BYTE)( dir & 0x0F))
#define CAN_MSG_FLAGS_EXT( dir, rtr, wu, nerr) \
                                 ( BYTE)( ( ( BYTE)( rtr  & 0x01) << 7) | \
                                          ( ( BYTE)( wu   & 0x01) << 6) | \
                                          ( ( BYTE)( nerr & 0x01) << 5) | \
                                            ( BYTE)( dir  & 0x0F))
#define CAN_FD_MSG_EDL( f)      (BYTE) (f & 0x1) 
#define CAN_FD_MSG_BRS( f)      (BYTE) ((f & 0x2) >> 1) 
#define CAN_FD_MSG_ESI( f)      (BYTE) ((f & 0x4) >> 2) 


#define  CAN_FD_MSG_FLAGS( edl, brs, esi) \
	( BYTE)( ( ( BYTE)( edl  & 0x01)) | \
	( ( BYTE)( brs & 0x01) << 1) | \
	( BYTE)( esi  & 0x01) << 2)

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLCANErrorFrame_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    WORD            mLength;                     /* CAN error frame length */
} VBLCANErrorFrame;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLCANErrorFrameExt_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    WORD            mLength;                     /* CAN error frame length */
    DWORD           mFlags;                      /* extended CAN error frame flags */
    BYTE            mECC;                        /* error control code */
    BYTE            mPosition;                   /* error position */
    BYTE            mDLC;                        /* lower 4 bits: DLC from CAN-Core. Upper 4 bits: reserved */
    BYTE            mReserved1;
    DWORD           mFrameLengthInNS;            /* frame length in ns */
    DWORD           mID;                         /* frame ID from CAN-Core */
    WORD            mFlagsExt;                   /* extended error flags */
    WORD            mReserved2;
    BYTE            mData[8];                    /* Payload, only for CAN-Core */
} VBLCANErrorFrameExt;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLCANOverloadFrame_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    WORD            mDummy;                      /* pad */
} VBLCANOverloadFrame;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLCANDriverStatistic_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    WORD            mBusLoad;                    /* CAN bus load */
    DWORD           mStandardDataFrames;         /* standard CAN id data frames */
    DWORD           mExtendedDataFrames;         /* extended CAN id data frames */
    DWORD           mStandardRemoteFrames;       /* standard CAN id remote frames */
    DWORD           mExtendedRemoteFrames;       /* extented CAN id remote frames */
    DWORD           mErrorFrames;                /* CAN error frames */
    DWORD           mOverloadFrames;             /* CAN overload frames */
} VBLCANDriverStatistic;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLCANDriverError_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mTXErrors;                   /* # of TX errors */
    BYTE            mRXErrors;                   /* # of RX errors */
    DWORD           mErrorCode;                  /* CAN driver error code */
} VBLCANDriverError;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLCANDriverErrorExt_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mTXErrors;                   /* # of TX errors */
    BYTE            mRXErrors;                   /* # of RX errors */
    DWORD           mErrorCode;                  /* CAN driver error code */
    DWORD           mFlags;                      /* flags */
    BYTE            mState;                      /* state register */
    BYTE            mReserved1;
    WORD            mReserved2;
    DWORD           mReserved3[4];

} VBLCANDriverErrorExt;

#define BL_HWSYNC_FLAGS_TX      1                /* sync was sent from this channel */
#define BL_HWSYNC_FLAGS_RX      2                /* external sync received */
#define BL_HWSYNC_FLAGS_RX_THIS 4                /* sync received but generated from this hardware */

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLCANDriverHwSync_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* channel where sync occured */
    BYTE            mFlags;                      /* BL_HWSYNC_FLAGS_XXX */
    BYTE            mDummy;                      /* pad */
} VBLCANDriverHwSync;

/*----------------------------------------------------------------------------
|
| CAN extended objects
|
-----------------------------------------------------------------------------*/

/* HINT: This structure might be extended in future versions! */
typedef struct VBLCANMessage2_t
{
  VBLObjectHeader mHeader;                     /* object header */
  WORD            mChannel;                    /* application channel */
  BYTE            mFlags;                      /* CAN dir & rtr */
  BYTE            mDLC;                        /* CAN dlc */
  DWORD           mID;                         /* CAN ID */
  BYTE            mData[8];                    /* CAN data */
  DWORD           mFrameLength;                /* message length in ns - without 3 Interframe Space bits and by Rx-message also without 1 End-Of-Frame bit */
  BYTE            mBitCount;                   /* complete message length in bits */
  BYTE            mReserved1;                  /* reserved */
  WORD            mReserved2;                  /* reserved */
} VBLCANMessage2;

/*----------------------------------------------------------------------------
|
| CAN FD objects
| 
-----------------------------------------------------------------------------*/
/* HINT: This structure might be extended in future versions! */
typedef struct VBLCANFDMessage_t
{
	VBLObjectHeader mHeader;                     /* object header */
	WORD            mChannel;                    /* application channel */
	BYTE            mFlags;                      /* CAN dir & rtr */
	BYTE            mDLC;                        /* CAN dlc */
	DWORD           mID;                         /* CAN ID */
	DWORD           mFrameLength;                /* message length in ns - without 3 inter frame space bits and by Rx-message also without 1 End-Of-Frame bit */
	BYTE            mArbBitCount;                /* bit count of arbitration phase */
	BYTE            mCANFDFlags;                 /* CAN FD flags */
	BYTE            mValidDataBytes;             /* Valid payload length of mData */  
	BYTE            mReserved1;                  /* reserved */
	DWORD           mReserved2;                  /* reserved */
	BYTE            mData[64];                   /* CAN FD data */
} VBLCANFDMessage;

/*----------------------------------------------------------------------------
|
| CAN FD objects
| 
-----------------------------------------------------------------------------*/
typedef struct VBLCANFDMessage64_t
{
  VBLObjectHeader mHeader;                     /* object header */
  BYTE            mChannel;                    /* application channel */
  BYTE            mDLC;                        /* CAN dlc */
  BYTE            mValidDataBytes;             /* Valid payload length of mData */  
  BYTE            mTxCount;                    /* TXRequiredCount (4 bits), TxReqCount (4 Bits) */
  DWORD           mID;                         /* CAN ID */
  DWORD           mFrameLength;                /* message length in ns - without 3 inter frame space bits */
                                               /* and by Rx-message also without 1 End-Of-Frame bit */
  DWORD           mFlags;                 	   /* flags */
  DWORD           mBtrCfgArb;                  /* bit rate used in arbitration phase */
  DWORD           mBtrCfgData;                 /* bit rate used in data phase */
  DWORD	          mTimeOffsetBrsNs;            /* time offset of brs field */
  DWORD	          mTimeOffsetCrcDelNs;         /* time offset of crc delimiter field */
  WORD	          mBitCount;                   /* complete message length in bits */
  BYTE			  mDir;
  BYTE            mReserved1;                  
  DWORD           mCRC;                        /*CRC for CAN */
  BYTE            mData[64];                   /* CAN FD data */
} VBLCANFDMessage64;


typedef struct VBLCANFDErrorFrame64_t
{
	VBLObjectHeader mHeader;                     /* object header */
	BYTE            mChannel;                    /* application channel */
	BYTE            mDLC;                        /* CAN dlc */
	BYTE            mValidDataBytes;             /* Valid payload length of mData */
	BYTE			mECC;
	WORD			mFlags;
	WORD            mErrorCodeExt;
	WORD			mExtFlags;					 /* FD specific flags */
	WORD			reserved1;
	DWORD           mID;                         /* CAN ID */
	DWORD           mFrameLength;                /* message length in ns - without 3 inter frame space bits */
											     /* and by Rx-message also without 1 End-Of-Frame bit */
	DWORD           mBtrCfgArb;                  /* bit rate used in arbitration phase */
	DWORD           mBtrCfgData;                 /* bit rate used in data phase */
	DWORD	        mTimeOffsetBrsNs;            /* time offset of brs field */
	DWORD	        mTimeOffsetCrcDelNs;          /* time offset of crc delimiter field */
	DWORD           mCRC;						
	WORD	        mErrorPosition;               /* error position as bit offset */
	WORD            mReserved2;
	BYTE            mData[64];                   /* CAN FD data */
} VBLCANFDErrorFrame64;

/*----------------------------------------------------------------------------
|
| LIN objects
|
-----------------------------------------------------------------------------*/
/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINMessage_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mID;                         /* LIN ID */
    BYTE            mDLC;                        /* LIN DLC */
    BYTE            mData[8];                    /* t.b.d. */
    BYTE            mFSMId;                      /* t.b.d. */
    BYTE            mFSMState;                   /* t.b.d. */
    BYTE            mHeaderTime;                 /* t.b.d. */
    BYTE            mFullTime;                   /* t.b.d. */
    WORD            mCRC;                        /* t.b.d. */
    BYTE            mDir;                        /* t.b.d. */
    BYTE            mReserved;                   /* t.b.d. */
} VBLLINMessage;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINCRCError_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mID;                         /* LIN ID */
    BYTE            mDLC;                        /* LIN DLC */
    BYTE            mData[8];                    /* t.b.d. */
    BYTE            mFSMId;                      /* t.b.d. */
    BYTE            mFSMState;                   /* t.b.d. */
    BYTE            mHeaderTime;                 /* t.b.d. */
    BYTE            mFullTime;                   /* t.b.d. */
    WORD            mCRC;                        /* t.b.d. */
    BYTE            mDir;                        /* t.b.d. */
    BYTE            mReserved;                   /* t.b.d. */
} VBLLINCRCError;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINDLCInfo_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mID;                         /* LIN ID */
    BYTE            mDLC;                        /* LIN DLC */
} VBLLINDLCInfo;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINChecksumInfo_t
{
  VBLObjectHeader mHeader;                     /* object header */
  WORD            mChannel;                    /* application channel */
  BYTE            mID;                         /* LIN ID */
  BYTE            mChecksumModel;              /* LIN checksum model */
} VBLLINChecksumInfo;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINReceiveError_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mID;                         /* LIN ID */
    BYTE            mDLC;                        /* LIN DLC */
    BYTE            mFSMId;                      /* t.b.d. */
    BYTE            mFSMState;                   /* t.b.d. */
    BYTE            mHeaderTime;                 /* t.b.d. */
    BYTE            mFullTime;                   /* t.b.d. */
    BYTE            mStateReason;                /* t.b.d. */
    BYTE            mOffendingByte;              /* t.b.d. */
    BYTE            mShortError;                 /* t.b.d. */
    BYTE            mTimeoutDuringDlcDetection;  /* t.b.d. */
} VBLLINReceiveError;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINSendError_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mID;                         /* LIN ID */
    BYTE            mDLC;                        /* LIN DLC */
    BYTE            mFSMId;                      /* t.b.d. */
    BYTE            mFSMState;                   /* t.b.d. */
    BYTE            mHeaderTime;                 /* t.b.d. */
    BYTE            mFullTime;                   /* t.b.d. */
} VBLLINSendError;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINSlaveTimeout_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mSlaveID;                    /* t.b.d. */
    BYTE            mStateID;                    /* t.b.d. */
    DWORD           mFollowStateID;              /* t.b.d. */
} VBLLINSlaveTimeout;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINSchedulerModeChange_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mOldMode;                    /* t.b.d. */
    BYTE            mNewMode;                    /* t.b.d. */
} VBLLINSchedulerModeChange;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINSyncError_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    WORD            mDummy;                      /* t.b.d */
    WORD            mTimeDiff[4];                /* t.b.d */
} VBLLINSyncError;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINBaudrateEvent_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    WORD            mDummy;                      /* t.b.d */
    LONG            mBaudrate;                   /* t.b.d */
} VBLLINBaudrateEvent;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINSleepModeEvent_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mReason;                     /* t.b.d */
    BYTE            mFlags;                      /* LIN "was awake", "is awake" & "external" */
} VBLLINSleepModeEvent;

#define LIN_SLEEP_WAS_AWAKE 0x01
#define LIN_SLEEP_IS_AWAKE  0x02
#define LIN_SLEEP_EXTERNAL  0x04

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINWakeupEvent_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mSignal;                     /* t.b.d */
    BYTE            mExternal;                   /* t.b.d */
} VBLLINWakeupEvent;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINSpikeEvent_t
{
  VBLObjectHeader mHeader;                       /* object header */
  WORD            mChannel;                      /* application channel */
  ULONG           mWidth;                        /* the spike's width */

} VBLLINSpikeEvent;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINStatisticEvent_t
{
  VBLObjectHeader mHeader;                       /* object header */
  WORD            mChannel;                      /* application channel */
  double          mBusLoad;                      /* bus load */
  ULONG           mBurstsTotal;                  /* bursts total */
  ULONG           mBurstsOverrun;                /* bursts overrun */
  ULONG           mFramesSent;                   /* frames sent */
  ULONG           mFramesReceived;               /* frames received */
  ULONG           mFramesUnanswered;             /* frames unanswered */
} VBLLINStatisticEvent;


/*----------------------------------------------------------------------------
|
| MOST objects
|
-----------------------------------------------------------------------------*/
/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTSpy_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mDir;                        /* t.b.d */
    BYTE            mDummy1;                     /* t.b.d */
    DWORD           mSourceAdr;                  /* t.b.d */
    DWORD           mDestAdr;                    /* t.b.d */
    BYTE            mMsg[17];                    /* t.b.d */
    BYTE            mDummy2;                     /* t.b.d */
    WORD            mRTyp;                       /* t.b.d */
    BYTE            mRTypAdr;                    /* t.b.d */
    BYTE            mState;                      /* t.b.d */
    BYTE            mDummy3;                     /* t.b.d */
    BYTE            mAckNack;                    /* t.b.d */
    DWORD           mCRC;                        /* t.b.d */
} VBLMOSTSpy;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTCtrl_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mDir;                        /* t.b.d */
    BYTE            mDummy1;                     /* t.b.d */
    DWORD           mSourceAdr;                  /* t.b.d */
    DWORD           mDestAdr;                    /* t.b.d */
    BYTE            mMsg[17];                    /* t.b.d */
    BYTE            mDummy2;                     /* t.b.d */
    WORD            mRTyp;                       /* t.b.d */
    BYTE            mRTypAdr;                    /* t.b.d */
    BYTE            mState;                      /* t.b.d */
    BYTE            mDummy3H;                    /* t.b.d */
    BYTE            mAckNack;                    /* acknowledge bits */
} VBLMOSTCtrl;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTLightLock_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    SHORT           mState;                      /* t.b.d */
} VBLMOSTLightLock;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTStatistic_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    WORD            mPktCnt;                     /* t.b.d */
    LONG            mFrmCnt;                     /* t.b.d */
    LONG            mLightCnt;                   /* t.b.d */
    LONG            mBufferLevel;                /* t.b.d */
} VBLMOSTStatistic;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTPkt_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mDir;                        /* t.b.d */
    BYTE            mDummy1;                     /* t.b.d */
    DWORD           mSourceAdr;                  /* t.b.d */
    DWORD           mDestAdr;                    /* t.b.d */
    BYTE            mArbitration;
    BYTE            mTimeRes;
    BYTE            mQuadsToFollow;
    WORD            mCRC; 
    BYTE            mPriority;
    BYTE            mTransferType;
    BYTE            mState;
    DWORD           mPktDataLength;              /* length of variable data in bytes */
    LPBYTE          mPktData;                    /* variable data */
} VBLMOSTPkt;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTPkt2_t
{
    VBLObjectHeader2 mHeader;                    /* object header - NOTE! set the object size to*/
                                                 /* */
                                                 /* mHeader.mObjectSize = sizeof( VBLMOSTPkt2) + mPktDataLength; */
                                                 /* */
    WORD             mChannel;                   /* application channel */
    BYTE             mDir;                       /* t.b.d */
    BYTE             mDummy1;                    /* t.b.d */
    DWORD            mSourceAdr;                 /* t.b.d */
    DWORD            mDestAdr;                   /* t.b.d */
    BYTE             mArbitration;
    BYTE             mTimeRes;
    BYTE             mQuadsToFollow;
    WORD             mCRC; 
    BYTE             mPriority;
    BYTE             mTransferType;
    BYTE             mState;
    DWORD            mPktDataLength;             /* length of variable data in bytes */
    LPBYTE           mPktData;                   /* variable data */
} VBLMOSTPkt2;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTHWMode_t
{
    VBLObjectHeader2 mHeader;                    /* object header */
    WORD             mChannel;                   /* application channel */
    WORD             mDummy1;
    WORD             mHWMode;                    /* bypass/master/slave/spy */
    WORD             mHWModeMask;                /* marks the altered bits */
} VBLMOSTHWMode;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTReg_t
{
    VBLObjectHeader2 mHeader;                    /* object header */
    WORD             mChannel;                   /* application channel */
    BYTE             mSubType;                   /* read/write request/result */
    BYTE             mDummy1;
    DWORD            mHandle;                    /* operation handle */
    DWORD            mOffset;                    /* start address */
    WORD             mChip;                      /* chip id */
    WORD             mRegDataLen;                /* number of bytes */
    BYTE             mRegData[16];               /* data bytes */
} VBLMOSTReg;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTGenReg_t
{
    VBLObjectHeader2 mHeader;                    /* object header */
    WORD             mChannel;                   /* application channel */
    BYTE             mSubType;                   /* read/write request/result */
    BYTE             mDummy1;
    DWORD            mHandle;                    /* operation handle */
    WORD             mRegId;                     /* register ID */
    WORD             mDummy2;
    DWORD            mDummy3;
    ULONGLONG        mRegValue;                  /* register value */
} VBLMOSTGenReg;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTNetState_t
{
    VBLObjectHeader2 mHeader;                    /* object header */
    WORD             mChannel;                   /* application channel */
    WORD             mStateNew;                  /* MOST NetState */
    WORD             mStateOld;
    WORD             mDummy1;
} VBLMOSTNetState;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTDataLost_t
{
    VBLObjectHeader2 mHeader;                    /* object header */
    WORD             mChannel;                   /* application channel */
    WORD             mDummy1;
    DWORD            mInfo;                      /* info about data loss */
    DWORD            mLostMsgsCtrl;
    DWORD            mLostMsgsAsync;
    ULONGLONG        mLastGoodTimeStampNS;
    ULONGLONG        mNextGoodTimeStampNS;
} VBLMOSTDataLost;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTTrigger_t
{
    VBLObjectHeader2 mHeader;                    /* object header */
    WORD             mChannel;                   /* application channel */
    WORD             mDummy1;
    WORD             mMode;                      /* trigger mode */
    WORD             mHW;                        /* HW info */
    DWORD            mPreviousTriggerValue;
    DWORD            mCurrentTriggerValue;
} VBLMOSTTrigger;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTStatisticEx_t
{
    VBLObjectHeader2 mHeader;                    /* object header */
    WORD             mChannel;                   /* application channel */
    WORD             mDummy1;
    DWORD            mCodingErrors;
    DWORD            mFrameCounter;
} VBLMOSTStatisticEx;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTTxLight_t
{
    VBLObjectHeader2 mHeader;                    /* object header */
    WORD             mChannel;                   /* application channel */
    WORD             mState;                     
} VBLMOSTTxLight;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTAllocTab_t
{
    VBLObjectHeader2 mHeader;                    /* object header - NOTE! set the object size to*/
                                                 /* */
                                                 /* mHeader.mObjectSize = sizeof( VBLMOSTAllocTab) + mLength; */
                                                 /* */
    WORD             mChannel;                   /* application channel */
    WORD             mLength; 
    LPBYTE           mTableData;
} VBLMOSTAllocTab;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTStress_t
{
    VBLObjectHeader2 mHeader;                    /* object header */
    WORD             mChannel;                   /* application channel */
    WORD             mState;                     
    WORD             mMode;
    WORD             mDummy1;
} VBLMOSTStress;

/* HINT: This structure might be extended in future versions! */
typedef struct VBLMOSTEcl_t
{
    VBLObjectHeader2 mHeader;                    /* object header */
    WORD             mChannel;                   /* application channel */
    WORD             mMode;
    WORD             mEclState;                  /* Electrical Control Line level */
    WORD             mDummy2;
} VBLMOSTEcl;


/*----------------------------------------------------------------------------
|
| MOST 50/150 objects
|
-----------------------------------------------------------------------------*/
/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOST150Message_t
{
  VBLObjectHeader2 mHeader;                    /* object header - NOTE! set the object size to */
                                               /* mHeader.mObjectSize = sizeof(VBLMOST150Message) + mMsgLen; */
  WORD             mChannel;                   /* application channel */
  BYTE             mDir;                       /* direction: 0: Rx; 1: Tx; 2: TxRequest */
  BYTE             mDummy1;
  DWORD            mSourceAdr;                 /* source address */
  DWORD            mDestAdr;                   /* target address */
  BYTE             mTransferType;              /* 1: node message; 2: spy message*/
  BYTE             mState;                     /* transmission status */
  BYTE             mAckNack;                   /* acknowledge code */
  BYTE             mDummy2;
  DWORD            mCRC;                       /* Cyclic Redundancy Check */
  BYTE             mPAck;                      /* a preemptive acknowledge code */
  BYTE             mCAck;                      /* CRC acknowledge from the packet receiver(s) to the packet transmitter */
  BYTE             mPriority;                  /* priority of the message */
  BYTE             mPIndex;                    /* packet index, increments per message on MOST */
  DWORD            mMsgLen;                    /* length of variable data in bytes (51 max) */
  LPBYTE           mMsg;                       /* variable data */
} VBLMOST150Message;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOST150Pkt_t
{
  VBLObjectHeader2 mHeader;                    /* object header - NOTE! set the object size to */
                                               /* mHeader.mObjectSize = sizeof(VBLMOST150Pkt) + mPktDataLength; */
  WORD             mChannel;                   /* application channel */
  BYTE             mDir;                       /* direction: 0: Rx; 1: Tx; 2: TxRequest */
  BYTE             mDummy1;
  DWORD            mSourceAdr;                 /* source address */
  DWORD            mDestAdr;                   /* target address */
  BYTE             mTransferType;              /* 1: node message; 2: spy message*/
  BYTE             mState;                     /* transmission status */
  BYTE             mAckNack;                   /* acknowledge code */
  BYTE             mDummy2;
  DWORD            mCRC;                       /* Cyclic Redundancy Check */
  BYTE             mPAck;                      /* a preemptive acknowledge code */
  BYTE             mCAck;                      /* CRC acknowledge from the packet receiver(s) to the packet transmitter */
  BYTE             mPriority;                  /* priority of the message */
  BYTE             mPIndex;                    /* packet index, increments per message on MOST */
  DWORD            mPktDataLength;             /* length of variable data in bytes (1014 max) */
  LPBYTE           mPktData;                   /* variable data */
} VBLMOST150Pkt;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTEthernetPkt_t
{
  VBLObjectHeader2 mHeader;                    /* object header - NOTE! set the object size to */
                                               /* mHeader.mObjectSize = sizeof(VBLMOSTEthernetPkt) + mPktDataLength; */
  WORD             mChannel;                   /* application channel */
  BYTE             mDir;                       /* direction: 0: Rx; 1: Tx; 2: TxRequest */
  BYTE             mDummy1;
  ULONGLONG        mSourceMacAdr;              /* 48 bit source address */
  ULONGLONG        mDestMacAdr;                /* 48 bit target address */
  BYTE             mTransferType;              /* 1: node message; 2: spy message*/
  BYTE             mState;                     /* transmission status */
  BYTE             mAckNack;                   /* acknowledge code */
  BYTE             mDummy2;
  DWORD            mCRC;                       /* Cyclic Redundancy Check */
  BYTE             mPAck;                      /* a preemptive acknowledge code */
  BYTE             mCAck;                      /* CRC acknowledge from the packet receiver(s) to the packet transmitter */
  WORD             mDummy3;
  DWORD            mPktDataLength;             /* length of variable data in bytes (1506 max) */
  LPBYTE           mPktData;                   /* variable data */
} VBLMOSTEthernetPkt;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOST150MessageFragment_t     /* applied for MOST50 and MOST150 */
{
  VBLObjectHeader2 mHeader;                    /* object header - NOTE! set the object size to */
                                               /* mHeader.mObjectSize = sizeof(VBLMOST150MessageFragment) + mFirstDataLen; */
  WORD             mChannel;                   /* application channel */
  BYTE             mDummy1;
  BYTE             mAckNack;                   /* acknowledge code */
  DWORD            mValidMask;                 /* bitfield indicating which members have valid data */
  DWORD            mSourceAdr;                 /* source address */
  DWORD            mDestAdr;                   /* target address */
  BYTE             mPAck;                      /* a preemptive acknowledge code */
  BYTE             mCAck;                      /* CRC acknowledge from the packet receiver(s) to the packet transmitter */
  BYTE             mPriority;                  /* priority of the message */
  BYTE             mPIndex;                    /* packet index, increments per message on MOST */
  DWORD            mCRC;                       /* Cyclic Redundancy Check */
  DWORD            mDataLen;                   /* number of transmitted user data bytes */
  DWORD            mDataLenAnnounced;          /* announced user data length at the start of the transmission */
  DWORD            mFirstDataLen;              /* number of bytes in mFirstData */
  LPBYTE           mFirstData;                 /* variable data */
} VBLMOST150MessageFragment;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOST150PktFragment_t         /* applied for MOST50 and MOST150 */
{
  VBLObjectHeader2 mHeader;                    /* object header - NOTE! set the object size to */
                                               /* mHeader.mObjectSize = sizeof(VBLMOST150PktFragment) + mFirstDataLen; */
  WORD             mChannel;                   /* application channel */
  BYTE             mDummy1;
  BYTE             mAckNack;                   /* acknowledge code */
  DWORD            mValidMask;                 /* bitfield indicating which members have valid data */
  DWORD            mSourceAdr;                 /* source address */
  DWORD            mDestAdr;                   /* target address */
  BYTE             mPAck;                      /* a preemptive acknowledge code */
  BYTE             mCAck;                      /* CRC acknowledge from the packet receiver(s) to the packet transmitter */
  BYTE             mPriority;                  /* priority of the message */
  BYTE             mPIndex;                    /* packet index, increments per message on MOST */
  DWORD            mCRC;                       /* Cyclic Redundancy Check */
  DWORD            mDataLen;                   /* number of transmitted user data bytes */
  DWORD            mDataLenAnnounced;          /* announced user data length at the start of the transmission */
  DWORD            mFirstDataLen;              /* number of bytes in mFirstData */
  LPBYTE           mFirstData;                 /* variable data */
} VBLMOST150PktFragment;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTEthernetPktFragment_t
{
  VBLObjectHeader2 mHeader;                    /* object header - NOTE! set the object size to */
                                               /* mHeader.mObjectSize = sizeof(VBLMOSTEthernetPktFragment) + mFirstDataLen; */
  WORD             mChannel;                   /* application channel */
  BYTE             mDummy1;
  BYTE             mAckNack;                   /* acknowledge code */
  DWORD            mValidMask;                 /* bitfield indicating which members have valid data */
  ULONGLONG        mSourceMacAdr;              /* 48 bit source address */
  ULONGLONG        mDestMacAdr;                /* 48 bit target address */
  BYTE             mPAck;                      /* a preemptive acknowledge code */
  BYTE             mCAck;                      /* CRC acknowledge from the packet receiver(s) to the packet transmitter */
  WORD             mDummy2;
  DWORD            mCRC;                       /* Cyclic Redundancy Check */
  DWORD            mDataLen;                   /* number of transmitted user data bytes */
  DWORD            mDataLenAnnounced;          /* announced user data length at the start of the transmission */
  DWORD            mFirstDataLen;              /* number of bytes in mFirstData */
  LPBYTE           mFirstData;                 /* variable data */
} VBLMOSTEthernetPktFragment;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOSTSystemEvent_t
{
  VBLObjectHeader2 mHeader;                    /* object header */
  WORD             mChannel;                   /* application channel */
  WORD             mId;                        /* identifier of transported data */
  DWORD            mValue;                     /* current value */
  DWORD            mValueOld;                  /* previous value */
} VBLMOSTSystemEvent;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOST150AllocTab_t            /* applied for MOST50 and MOST150 */
{
  VBLObjectHeader2 mHeader;                    /* object header - NOTE! set the object size too */
  WORD             mChannel;                   /* application channel */
  WORD             mEventModeFlags;            /* determines the data layout */
  WORD             mFreeBytes;                 /* number of free bytes after the operation */
  WORD             mLength;                    /* number of bytes in mTableData*/
  LPBYTE           mTableData;
  /*
    Data layout:
    if((mEventModeFlags & 0x0001) == 0)
      layout A: SLLLWWWWSLLLWWWWSLLLWWWW...
    if((mEventModeFlags & 0x0001) == 0x0001)
      layout B: SLLLWWWW<channels>SLLLWWWW<channels>SLLLWWWW<channels>...
    S:    status flags
          0x4: 1: new label (alloc)
          0x8: 1: this label has been removed (dealloc)
    LLL:  label number
    WWWW: label width
    <channels>: list of 16-bit channel numbers (size = label width)
  */
} VBLMOST150AllocTab;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOST50Message_t
{
  VBLObjectHeader2 mHeader;                    /* object header - NOTE! set the object size to */
  /* mHeader.mObjectSize = sizeof(VBLMOST50Message) + mMsgLen; */
  WORD             mChannel;                   /* application channel */
  BYTE             mDir;                       /* direction: 0: Rx; 1: Tx; 2: TxRequest */
  BYTE             mDummy1;
  DWORD            mSourceAdr;                 /* source address */
  DWORD            mDestAdr;                   /* target address */
  BYTE             mTransferType;              /* 1: node message; 2: spy message*/
  BYTE             mState;                     /* transmission status */
  BYTE             mAckNack;                   /* acknowledge code */
  BYTE             mDummy2;
  DWORD            mCRC;                       /* Cyclic Redundancy Check */
  BYTE             mDummy3;                    /* reserved */
  BYTE             mDummy4;                    /* reserved */
  BYTE             mPriority;                  /* priority of the message */
  BYTE             mDummy5;                    /* reserved */
  DWORD            mMsgLen;                    /* length of variable data in bytes (17 max) */
  LPBYTE           mMsg;                       /* variable data */
} VBLMOST50Message;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLMOST50Pkt_t
{
  VBLObjectHeader2 mHeader;                    /* object header - NOTE! set the object size to */
  /* mHeader.mObjectSize = sizeof(VBLMOST50Pkt) + mPktDataLength; */
  WORD             mChannel;                   /* application channel */
  BYTE             mDir;                       /* direction: 0: Rx; 1: Tx; 2: TxRequest */
  BYTE             mDummy1;
  DWORD            mSourceAdr;                 /* source address */
  DWORD            mDestAdr;                   /* target address */
  BYTE             mTransferType;              /* 1: node message; 2: spy message*/
  BYTE             mState;                     /* transmission status */
  BYTE             mAckNack;                   /* acknowledge code */
  BYTE             mDummy2;
  DWORD            mCRC;                       /* Cyclic Redundancy Check */
  BYTE             mDummy3;                    /* reserved */
  BYTE             mDummy4;                    /* reserved */
  BYTE             mPriority;                  /* priority of the message */
  BYTE             mDummy5;                    /* reserved */
  DWORD            mPktDataLength;             /* length of variable data in bytes (1014 max) */
  LPBYTE           mPktData;                   /* variable data */
} VBLMOST50Pkt;


/*----------------------------------------------------------------------------
|
| LIN extended objects
|
-----------------------------------------------------------------------------*/
/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINBusEvent_t
{
  ULONGLONG       mSOF;                        /* Start Of Frame timestamp */
  DWORD           mEventBaudrate;              /* Baudrate of the event in bit/sec */
  WORD            mChannel;                    /* application channel */
  BYTE            mReserved[2];                /* 4-byte alignment */

} VBLLINBusEvent;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINSynchFieldEvent_t
{
  VBLLINBusEvent  mLinBusEvent;                 /* LIN object header */
  ULONGLONG       mSynchBreakLength;            /* Sync Break Length in ns */
  ULONGLONG       mSynchDelLength;              /* Sync Delimiter Length in ns */
} VBLLINSynchFieldEvent;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINMessageDescriptor_t
{
  VBLLINSynchFieldEvent  mLinSynchFieldEvent;   /* LIN object header */
  WORD            mSupplierID;                  /* LIN Sub-Identifier - Supplier ID */
  WORD            mMessageID;                   /* LIN Sub-Identifier - Message ID (16 bits) */
  BYTE            mNAD;                         /* LIN Sub-Identifier - NAD */
  BYTE            mID;                          /* LIN ID */
  BYTE            mDLC;                         /* LIN DLC */
  BYTE            mChecksumModel;               /* LIN checksum model */
} VBLLINMessageDescriptor;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINDatabyteTimestampEvent_t
{
  VBLLINMessageDescriptor mLinMsgDescrEvent;       /* object header */
  ULONGLONG               mDatabyteTimestamps[9];  /* Databyte timestamps, where d[0] = EndOfHeader, d[1]=EndOfDataByte1, ..., d[8]=EndOfDataByte8 */
} VBLLINDatabyteTimestampEvent;

/* HINT: this struct might be extended in future versions! */
typedef struct VBLLINMessage2_t
{
  VBLObjectHeader mHeader;                     /* object header */
  VBLLINDatabyteTimestampEvent  mLinTimestampEvent;  /* LIN object header */
  BYTE            mData[8];                    /* data bytes. */
  WORD            mCRC;                        /* checksum byte */
  BYTE            mDir;                        /* direction */  
  BYTE            mSimulated;                  /* simulated frame */  
  BYTE            mIsETF;                      /* Event-triggered frame */
  BYTE            mETFAssocIndex;              /* Unconditional frame associated with ETF - serial index */
  BYTE            mETFAssocETFId;              /* Unconditional frame associated with ETF - id of ETF */
  BYTE            mFSMId;                      /* t.b.d. */
  BYTE            mFSMState;                   /* t.b.d. */
  BYTE            mReserved[3];                /* 4-byte alignment */
  DWORD           mRespBaudrate;               /* Response baudrate of the event in bit/sec */ 
  DOUBLE          mExactHeaderBaudrate;        /* Exact baudrate of the header in bit/sec */
  DWORD           mEarlyStopbitOffset;         /* Early stop bit offset for UART timestamps in ns */
  DWORD           mEarlyStopbitOffsetResponse; /* Early stop bit offset in frame response for UART timestamps in ns */
} VBLLINMessage2;

/* HINT: this struct might be extended in future versions! */
typedef struct VBLLINSendError2_t
{
  VBLObjectHeader mHeader;                     /* object header */
  VBLLINMessageDescriptor mLinMsgDescrEvent;   /* LIN object header */
  ULONGLONG       mEOH;                        /* EndOfHeader timestamp */
  BYTE            mIsETF;                      /* Event-triggered frame */
  BYTE            mFSMId;                      /* t.b.d. */
  BYTE            mFSMState;                   /* t.b.d. */
  BYTE            mReserved;                   /* 4-byte alignment */
  BYTE            mReserved2[4];               /* 4-byte alignment, reserved since BLF 3.9.3.0, BLF files from older versions may have junk data here */
  DOUBLE          mExactHeaderBaudrate;        /* Exact baudrate of the header in bit/sec */
  DWORD           mEarlyStopbitOffset;         /* Early stop bit offset for UART timestamps in ns */
} VBLLINSendError2;

/* HINT: this struct might be extended in future versions! */
typedef struct VBLLINSyncError2_t
{
  VBLObjectHeader mHeader;                     /* object header */
  VBLLINSynchFieldEvent  mLinSynchFieldEvent;  /* LIN object header */
  WORD            mTimeDiff[4];                /* t.b.d */
} VBLLINSyncError2;

/* HINT: this struct might be extended in future versions! */
typedef struct VBLLINCRCError2_t
{
  VBLObjectHeader mHeader;                     /* object header */
  VBLLINDatabyteTimestampEvent  mLinTimestampEvent;  /* LIN object header */
  BYTE            mData[8];                    /* data bytes. */
  WORD            mCRC;                        /* checksum byte */
  BYTE            mDir;                        /* direction */
  BYTE            mFSMId;                      /* t.b.d. */
  BYTE            mFSMState;                   /* t.b.d. */
  BYTE            mSimulated;                  /* simulated frame */  
  BYTE            mReserved[2];                /* 4-byte alignment */ 
  DWORD           mRespBaudrate;               /* Response baudrate of the event in bit/sec */
  BYTE            mReserved2[4];               /* 4-byte alignment, reserved since BLF 3.9.3.0, BLF files from older versions may have junk data here */
  DOUBLE          mExactHeaderBaudrate;        /* Exact baudrate of the header in bit/sec */
  DWORD           mEarlyStopbitOffset;         /* Early stop bit offset for UART timestamps in ns */
  DWORD           mEarlyStopbitOffsetResponse; /* Early stop bit offset in frame response for UART timestamps in ns */
} VBLLINCRCError2;

/* HINT: this struct might be extended in future versions! */
typedef struct VBLLINReceiveError2_t
{
  VBLObjectHeader mHeader;                     /* object header */
  VBLLINDatabyteTimestampEvent  mLinTimestampEvent;  /* LIN object header */
  BYTE            mData[8];                    /* data bytes. */
  BYTE            mFSMId;                      /* t.b.d. */
  BYTE            mFSMState;                   /* t.b.d. */
  BYTE            mStateReason;                /* t.b.d. */
  BYTE            mOffendingByte;              /* t.b.d. */
  BYTE            mShortError;                 /* t.b.d. */
  BYTE            mTimeoutDuringDlcDetection;  /* t.b.d. */ 
  BYTE            mIsETF;                      /* ETF collision flag */
  BYTE            mHasDatabytes;               /* t.b.d. */
  DWORD           mRespBaudrate;               /* Response baudrate of the event in bit/sec */
  BYTE            mReserved[4];                /* 4-byte alignment, reserved since BLF 3.9.3.0, BLF files from older versions may have junk data here */
  DOUBLE          mExactHeaderBaudrate;        /* Exact baudrate of the header in bit/sec */
  DWORD           mEarlyStopbitOffset;         /* Early stop bit offset for UART timestamps in ns */
  DWORD           mEarlyStopbitOffsetResponse; /* Early stop bit offset in frame response for UART timestamps in ns */
} VBLLINReceiveError2;

/* HINT: this struct might be extended in future versions! */
typedef struct VBLLINWakeupEvent2_t
{
  VBLObjectHeader mHeader;                     /* object header */
  VBLLINBusEvent  mLinBusEvent;                /* LIN object header */
  BYTE            mLengthInfo;                 /* t.b.d */
  BYTE            mSignal;                     /* t.b.d */
  BYTE            mExternal;                   /* t.b.d */
  BYTE            mReserved;                   /* 4-byte alignment */  
} VBLLINWakeupEvent2;

/* HINT: this struct might be extended in future versions! */
typedef struct VBLLINSpikeEvent2_t
{
  VBLObjectHeader mHeader;                     /* object header */
  VBLLINBusEvent  mLinBusEvent;                /* LIN object header */
  ULONG           mWidth;                      /* the spike's width in microseconds */
  BYTE            mInternal;                   /* t.b.d */
  BYTE            mReserved[3];                /* 4-byte alignment */  
} VBLLINSpikeEvent2;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLLINLongDomSignalEvent_t
{
  VBLObjectHeader mHeader;                     /* object header */
  VBLLINBusEvent  mLinBusEvent;                /* LIN object header */
  BYTE            mType;                       /* t.b.d */
  BYTE            mReserved[3];                /* 4-byte alignment */
} VBLLINLongDomSignalEvent;

/* HINT: this struct might be extended in future versions! */
typedef struct VBLLINLongDomSignalEvent2_t
{
  VBLObjectHeader mHeader;                     /* object header */
  VBLLINBusEvent  mLinBusEvent;                /* LIN object header */
  BYTE            mType;                       /* t.b.d */
  BYTE            mReserved[7];                /* 4-byte alignment */
  ULONGLONG       mLength;
} VBLLINLongDomSignalEvent2;

/* HINT: this struct might be extended in future versions! */
typedef struct VBLLINUnexpectedWakeup_t
{
  VBLObjectHeader mHeader;                     /* object header */
  VBLLINBusEvent  mLinBusEvent;                /* LIN object header */
  ULONGLONG       mWidth;                      /* width of the unexpected wakeup in nanoseconds (valid for LIN 2.x) */
  BYTE            mSignal;                     /* byte signal of the unexpected wakeup (valid for LIN 1.x) */
  BYTE            mReserved[7];                /* 8-byte alignment */
} VBLLINUnexpectedWakeup;

/* HINT: this struct might be extended in future versions! */
typedef struct VBLLINShortOrSlowResponse_t
{
  VBLObjectHeader mHeader;                     /* object header */
  VBLLINDatabyteTimestampEvent  mLinTimestampEvent;  /* LIN object header */
  ULONG           mNumberOfRespBytes;          /* number of valid response bytes */
  BYTE            mRespBytes[9];               /* the response bytes (can include the checksum) */
  BYTE            mSlowResponse;               /* non-zero, if the response was too slow */
  BYTE            mInterruptedByBreak;         /* non-zero, if the response was interrupted by a sync break */
  BYTE            mReserved[1];                /* 8-byte alignment */
} VBLLINShortOrSlowResponse;

/* HINT: this struct might be extended in future versions! */
typedef struct VBLLINDisturbanceEvent_t
{
  VBLObjectHeader mHeader;                     /* object header */
  WORD            mChannel;                    /* application channel */
  BYTE            mID;                         /* LIN ID of disturbed response */
  BYTE            mDisturbingFrameID;          /* LIN ID of disturbing header */
  ULONG           mDisturbanceType;            /* type of disturbance (dominant, recessive, header, bitstream, variable bitstream) */
  ULONG           mByteIndex;                  /* index of the byte that was disturbed */
  ULONG           mBitIndex;                   /* index of the bit that was disturbed */
  ULONG           mBitOffsetInSixteenthBits;   /* offset in 1/16th bits into the disturbed bit */
  ULONG           mDisturbanceLengthInSixteenthBits; /* length of the disturbance in units of 1/16th bit */
} VBLLINDisturbanceEvent;

/*----------------------------------------------------------------------------
|
| FLEXRAY objects
|
-----------------------------------------------------------------------------*/
/* HINT: Extension of this structure is not allowed! */
typedef struct VBLFLEXRAYData_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mMUX;                        /* t.b.d */
    BYTE            mLen;                        /* t.b.d */
    WORD            mMessageID;                  /* t.b.d */
    WORD            mCRC;                        /* t.b.d */
    BYTE            mDir;                        /* t.b.d */
    BYTE            mDummy1;                     /* t.b.d */
    WORD            mDummy2;                     /* t.b.d */
    BYTE            mDataBytes[12];              /* t.b.d */
} VBLFLEXRAYData;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLFLEXRAYSync_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mMUX;                        /* t.b.d */
    BYTE            mLen;                        /* t.b.d */
    WORD            mMessageID;                  /* t.b.d */
    WORD            mCRC;                        /* t.b.d */
    BYTE            mDir;                        /* t.b.d */
    BYTE            mDummy1;                     /* t.b.d */
    WORD            mDummy2;                     /* t.b.d */
    BYTE            mDataBytes[11];              /* t.b.d */
    BYTE            mCycle;                      /* t.b.d */
} VBLFLEXRAYSync;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLFLEXRAYV6StartCycleEvent_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mDir;                        /* dir flag (tx, rx) */
    BYTE            mLowTime;                    /* additional time field in simulation */
    DWORD           mFPGATick;                   /* timestamp generated from xModule */
    DWORD           mFPGATickOverflow;           /* overflow counter of the timestamp */
    DWORD           mClientIndex;                /* clientindex of send node */
    DWORD           mClusterTime;                /* relatvie clustertime, from 0 to cyclelength*/
    BYTE            mDataBytes[2];               /* array of databytes*/
    WORD            mReserved;
} VBLFLEXRAYV6StartCycleEvent;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLFLEXRAYV6Message_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mDir;                        /* dir flag (tx, rx) */
    BYTE            mLowTime;                    /* additional time field in simulation */
    DWORD           mFPGATick;                   /* timestamp generated from xModule */
    DWORD           mFPGATickOverflow;           /* overflow counter of the timestamp */
    DWORD           mClientIndex;                /* clientindex of send node */
    DWORD           mClusterTime;                /* relatvie clustertime, from 0 to cyclelength*/
    WORD            mFrameId;                    /* slot identifier, word  */
    WORD            mHeaderCRC;                  /*                  word  */
    WORD            mFrameState;                 /* V6 framestate          */
    BYTE            mLength;                     /* dlc of message,  byte  */    
    BYTE            mCycle;                      /* current cycle,   byte  */
    BYTE            mHeaderBitMask;              /* Bit0 = NMBit, Bit1 = SyncBit, Bit2 = Reserved */
    BYTE            mReserved1;
    WORD            mReserved2;
    BYTE            mDataBytes[64];              /* array of databytes*/
} VBLFLEXRAYV6Message;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLFLEXRAYStatusEvent_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    WORD            mVersion;                    /* object version */
    WORD            mStatusType;                 /* type of status event */
    WORD            mInfoMask1;                  /* additional info 1 */
    WORD            mInfoMask2;                  /* additional info 2 */
    WORD            mInfoMask3;                  /* additional info 3 */
    WORD            mReserved[16];
} VBLFLEXRAYStatusEvent;

// New FlexRay events
/* HINT: Extension of this structure is not allowed! */
typedef struct VBLFLEXRAYVFrReceiveMsgEx_t
{
  VBLObjectHeader mHeader;                     /* object header */
  WORD            mChannel;                    /* application channel */
  WORD            mVersion;                    /* version of data struct */
  WORD            mChannelMask;                /* channel mask */
  WORD            mDir;                        /* dir flag (tx, rx) */
  DWORD           mClientIndex;                /* clientindex of send node */
  DWORD           mClusterNo;                  /* number of cluster */
  WORD            mFrameId;                    /* slot identifier, word  */
  WORD            mHeaderCRC1;                 /* header crc channel 1  */
  WORD            mHeaderCRC2;                 /* header crc channel 2  */
  WORD            mByteCount;                  /* byte count (not payload) of frame from CC receive buffer */
  WORD            mDataCount;                  /* length of the data array (stretchy struct) */
  WORD            mCycle;                      /* current cycle, byte  */
  DWORD           mTag;                        /* type of cc */
  DWORD           mData;                       /* register flags */
  DWORD           mFrameFlags;                 /* frame flags */
  DWORD           mAppParameter;               /* TxRq, TxAck flags */
  DWORD           mFrameCRC;                   /* frame crc */     
  DWORD           mFrameLengthNS;              /* length of frame in ns */
  WORD            mFrameId1;                   /* for internal use */
  WORD            mPDUOffset;                  /* payload offset (position in a frame) */
  WORD            mBlfLogMask;                 /* only valid for frames. Every stands for one PDU. If set, the PDU must be extracted out of the frame. The bit order is the PDU order in the frame starting with the PDU with the smallest offset */
  WORD            mReservedW;
  DWORD           mReserved[6];                /* reserved */
  BYTE            mDataBytes[254];             /* array of databytes*/   
} VBLFLEXRAYVFrReceiveMsgEx;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLFLEXRAYVFrReceiveMsg_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    WORD            mVersion;                    /* version of data struct */
    WORD            mChannelMask;                /* channel mask */
    BYTE            mDir;                        /* dir flag (tx, rx) */
    DWORD           mClientIndex;                /* clientindex of send node */
    DWORD           mClusterNo;                  /* number of cluster */
    WORD            mFrameId;                    /* slot identifier, word  */
    WORD            mHeaderCRC1;                 /* header crc channel 1  */
    WORD            mHeaderCRC2;                 /* header crc channel 2  */
    WORD            mByteCount;                  /* byte count (not payload) of frame from CC receive buffer */
    WORD            mDataCount;                  /* length of the data array (stretchy struct) */
    BYTE            mCycle;                      /* current cycle, byte  */
    DWORD           mTag;                        /* type of cc */
    DWORD           mData;                       /* register flags */
    DWORD           mFrameFlags;                 /* frame flags */
    DWORD           mAppParameter;               /* TxRq, TxAck flags */
    BYTE            mDataBytes[254];             /* array of databytes*/
} VBLFLEXRAYVFrReceiveMsg;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLFLEXRAYVFrStartCycle_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    WORD            mVersion;                    /* version of data struct */
    WORD            mChannelMask;                /* channel mask */
    BYTE            mDir;                        /* dir flag (tx, rx) */
    BYTE            mCycle;                      /* current cycle,   byte  */
    DWORD           mClientIndex;                /* clientindex of send node */
    DWORD           mClusterNo;                  /* number of cluster */
    WORD            mNmSize;                     /* size of NM Vector */
    BYTE            mDataBytes[12];              /* array of databytes (NM vector max. length)*/
    DWORD           mTag;                        /* type of cc */
    DWORD           mData[5];                    /* register flags */
    WORD            mReserved;
} VBLFLEXRAYVFrStartCycle;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLFLEXRAYVFrStatus_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    WORD            mVersion;                    /* object version */
    WORD            mChannelMask;                /* channel mask */
    BYTE            mCycle;                      /* current cycle,   byte */
    DWORD           mClientIndex;                /* clientindex of send node */
    DWORD           mClusterNo;                  /* number of cluster */
    DWORD           mWus;                        /* wakeup status */
    DWORD           mCcSyncState;                /* sync state of cc */
    DWORD           mTag;                        /* type of cc */    
    DWORD           mData[2];                    /* register flags */
    WORD            mReserved[16];
} VBLFLEXRAYVFrStatus;

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLFLEXRAYVFrError_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    WORD            mVersion;                    /* object version */
    WORD            mChannelMask;                /* channel mask */
    BYTE            mCycle;                      /* current cycle, byte */
    DWORD           mClientIndex;                /* clientindex of send node */
    DWORD           mClusterNo;                  /* number of cluster */
    DWORD           mTag;                        /* type of cc */
    DWORD           mData[4];                    /* register flags */
    WORD            mReserved;
} VBLFLEXRAYVFrError;

/*----------------------------------------------------------------------------
|
| J1708 message object
|
-----------------------------------------------------------------------------*/
/* HINT: Extension of this structure is not allowed! */
typedef struct VBLJ1708Message_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    BYTE            mDir;                        /* direction */
    WORD            mError;                      /* error code */
    BYTE            mSize;                       /* data size */
    BYTE            mData[255];                  /* data */
} VBLJ1708Message;

/*----------------------------------------------------------------------------
|
| Environment variable object
|
-----------------------------------------------------------------------------*/
/* HINT: Extension of this structure is not allowed! */
typedef struct VBLEnvironmentVariable_t
{
    VBLObjectHeader mHeader;                     /* object header - NOTE! set the object size to*/
                                                 /* */
                                                 /* mHeader.mObjectSize = sizeof( VBLEnvironmentVariable) + mNameLength + mDataLength; */
                                                 /* */
    DWORD           mNameLength;                 /* length of variable name in bytes */
    DWORD           mDataLength;                 /* length of variable data in bytes */
    LPSTR           mName;                       /* variable name in MBCS */
    LPBYTE          mData;                       /* variable data */
} VBLEnvironmentVariable;

/*----------------------------------------------------------------------------
|
| System variable object
|
-----------------------------------------------------------------------------*/

#define BL_SYSVAR_TYPE_DOUBLE       1
#define BL_SYSVAR_TYPE_LONG         2
#define BL_SYSVAR_TYPE_STRING       3
#define BL_SYSVAR_TYPE_DOUBLEARRAY  4
#define BL_SYSVAR_TYPE_LONGARRAY    5
#define BL_SYSVAR_TYPE_LONGLONG     6
#define BL_SYSVAR_TYPE_BYTEARRAY    7

/* HINT: Extension of this structure is not allowed! */
typedef struct VBLSystemVariable_t
{
    VBLObjectHeader mHeader;                     /* object header - NOTE! set the object size to*/
                                                 /* */
                                                 /* mHeader.mObjectSize = sizeof( VBLSystemVariable) + mNameLength + mDataLength; */
                                                 /* */
    DWORD           mType;                       /* type of system variable (see BL_SYSVAR_TYPE_xxx) */
    DWORD           mReserved[3];
    DWORD           mNameLength;                 /* length of variable name in bytes */
    DWORD           mDataLength;                 /* length of variable data in bytes */
    LPSTR           mName;                       /* variable name in MBCS */
    LPBYTE          mData;                       /* variable data */
} VBLSystemVariable;

/*----------------------------------------------------------------------------
|
| GPS event object
|
-----------------------------------------------------------------------------*/
/* HINT: Extension of this structure is not allowed! */
typedef struct VBLGPSEvent_t
{
    VBLObjectHeader mHeader;                     /* object header */
    DWORD           mFlags;                      /* t.b.d. */
    WORD            mChannel;                    /* channel of event */
    WORD            mReserved;                   /* t.b.d. */
    DOUBLE          mLatitude;                   /* t.b.d. */
    DOUBLE          mLongitude;                  /* t.b.d. */
    DOUBLE          mAltitude;                   /* t.b.d. */
    DOUBLE          mSpeed;                      /* t.b.d. */
    DOUBLE          mCourse;                     /* t.b.d. */
} VBLGPSEvent;

/*----------------------------------------------------------------------------
|
| Serial event object
|
-----------------------------------------------------------------------------*/

#define BL_SERIAL_TYPE_KLINE_EVENT   0x000000001
#define BL_SERIAL_TYPE_DIAG_REQUEST  0x000000002 /* only valid if BL_SERIAL_TYPE_KLINE_EVENT is set */
#define BL_SERIAL_TYPE_SINGLE_BYTE   0x000000004 /* optimization for logging single bytes */
#define BL_SERIAL_TYPE_COMPACT_BYTES 0x000000008 /* optimization for logging a few bytes without additional timestamps */

/* HINT: this struct might be extended in future versions! */
typedef struct VBLGeneralSerialEvent_t
{
    DWORD           mDataLength;                 /* length of variable data in bytes */
    DWORD           mTimeStampsLength;           /* length of variable timestamps in bytes */
    PBYTE           mData;                       /* variable data */
    PLONGLONG       mTimeStamps;                 /* variable timestamps (optional) */
} VBLGeneralSerialEvent;

/* HINT: this struct might be extended in future versions! */
typedef struct VBLSingleByteSerialEvent_t
{
    BYTE            mByte;
} VBLSingleByteSerialEvent;

/* HINT: this struct might be extended in future versions! */
typedef struct VBLCompactSerialEvent_t
{
    BYTE            mCompactLength;
    BYTE            mCompactData[15];
} VBLCompactSerialEvent;

/* HINT: this struct might be extended in future versions! */
typedef struct VBLSerialEvent_t
{
    VBLObjectHeader mHeader;                     /* object header */
    DWORD           mFlags;                      /* see above */
    DWORD           mPort;                       /* channel of event */
    DWORD           mBaudrate;                   /* baudrate at which this event was transmitted (optional) */
    DWORD           mReserved;                   /* t.b.d. */
    union
    {
        VBLGeneralSerialEvent    mGeneral;
        VBLSingleByteSerialEvent mSingleByte;
        VBLCompactSerialEvent    mCompact;
    };
} VBLSerialEvent;


#define BL_KLINE_TYPE_TOECU      0x8000       /* If set in mType, direction is tester -> ECU */
#define BL_KLINE_TYPE_MASK       0x7FFF       /* Use this mask to filter out the type from mType */
/* HINT: this struct might be extended in future versions! */
typedef struct VBLKLineStatusEvent_t
{
  VBLObjectHeader mHeader;                    /* object header */
  WORD            mType;                      /* BusSystemFacility::VKLineStatusEventType */
  WORD            mDataLen;                   /* number of *bytes* used in mData */
  DWORD           mPort;                      /* channel of event */
  DWORD           mReserved;                  /* t.b.d. */
  UINT64          mData[3];                   /* the actual data, but only mDataLen BYTES are used! */
} VBLKLineStatusEvent;

/*----------------------------------------------------------------------------
|
| Ethernet frame object
|
-----------------------------------------------------------------------------*/
/* HINT: Extension of this structure is not allowed! */
typedef struct VBLEthernetFrame_t
{
    VBLObjectHeader mHeader;                     /* object header - NOTE! set the object size to*/
                                                 /* mHeader.mObjectSize = sizeof( VBLEthernetFrame) + mPayLoadLength; */
    BYTE            mSourceAddress[6];
    WORD            mChannel;
    BYTE            mDestinationAddress[6];
    WORD            mDir;                        /* Direction flag: 0=Rx, 1=Tx, 2=TxRq */
    WORD            mType;
    WORD            mTPID;
    WORD            mTCI;
    WORD            mPayLoadLength;              /* Number of valid mPayLoad bytes */
    BYTE*           mPayLoad;                    /* Max 1500 data bytes per frame  */
} VBLEthernetFrame;

/*----------------------------------------------------------------------------
|
| Ethernet RX error
|
-----------------------------------------------------------------------------*/

typedef struct VBLEthernetRxError_t
{
    VBLObjectHeader mHeader;                     /* object header - NOTE! set the object size to*/
                                                 /* mHeader.mObjectSize = sizeof( VBLEthernetFrame2) + mRawDataLength - sizeof(BYTE*); */
    WORD            mStructLength;               /* Length of this structure, without sizeof(VBLObjectHeader) and without raw data length */
    WORD            mChannel;
    WORD            mDir;                        /* Direction flag: 0=Rx, 1=Tx, 2=TxRq */
    DWORD           mFcs;                        /* Frame Check Sum */
    WORD            mFrameDataLength;            /* Number of valid raw ethernet data bytes, starting with Target MAC ID */
    DWORD           mError;
                                                 /* extend structure here, if necessary */
    BYTE*           mFrameData;                  /* Max 1522 data bytes per frame  */
} VBLEthernetRxError;

/*----------------------------------------------------------------------------
|
| Ethernet Status
|
-----------------------------------------------------------------------------*/

typedef struct VBLEthernetStatus_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;
    WORD            mFlags;                      /* Valid fields: */
                                                 /* Bit 0 - Link Status */
                                                 /* Bit 1 - Bitrate */
                                                 /* Bit 2 - Ethernet Phy */
                                                 /* Bit 3 - Duplex */
    BYTE            mLinkStatus;                 /* Link Status:   */
                                                 /* 0 - Unknown    */
                                                 /* 1 - Link down  */
                                                 /* 2 - Link up    */
                                                 /* 3 - Negotiate  */
                                                 /* 4 - Link error */
    BYTE            mEthernetPhy;                /* Eternet Phy:     */
                                                 /* 0 - Unknown      */
                                                 /* 1 - IEEE 802.3   */
                                                 /* 2 - BroadR-Reach */
    BYTE            mDuplex;                     /* Duplex: */
                                                 /* 0 - Unknown     */
                                                 /* 1 - Half Duplex */
                                                 /* 2 - Full Duplex */
    BYTE            mMdi;                        /* 0 - Unknown */
                                                 /* 1 - Direct*/
                                                 /* 2 - Crossover */
    BYTE            mConnector;                  /* 0 - Unknown */
                                                 /* 1 - RJ45*/
                                                 /* 2 - D-Sub */
    BYTE            mClockMode;                  /* 0 - Unknown */
                                                 /* 1 - Master */
                                                 /* 2 - Slave */
    BYTE            mPairs;                      /* 0 - Unknown */
                                                 /* 1 - BR 1-pair*/
                                                 /* 2 - BR 2-pair */
                                                 /* 3 - BR 4-pair */
    BYTE            mReserved;
    DWORD           mBitrate;                    /* Bitrate in [kbit/sec] */
} VBLEthernetStatus;


/*----------------------------------------------------------------------------
|
| WLAN frame object
|
-----------------------------------------------------------------------------*/
/* HINT: Extension of this structure is not allowed! */
typedef struct VBLWlanFrame_t
{
    VBLObjectHeader mHeader;                     /* object header - NOTE! set the object size to*/
                                                 /* mHeader.mObjectSize = sizeof( VBLWlanFrame_t) + mFrameLength; */
    WORD            mChannel;                    /* application channel 1..n */
    WORD            mFlags;                      /* Bit0=Genuine MAC-Header */
    BYTE            mDir;                        /* Direction flag: 0=Rx, 1=Tx, 2=TxRq */
    BYTE            mRadioChannel;               /* channel number of the radio frequencey */
    SHORT           mSignalStrength;             /* signal strength in [dbm] */
    WORD            mSignalQuality;              /* signal quality in [dbm] */
    WORD            mFrameLength;                /* Number of bytes (header + payload) */
    BYTE*           mFrameData;                  /* Max. 2342 data bytes per frame  */
} VBLWlanFrame;

/* HINT: this struct might be extended in future versions! */
typedef struct VBLWlanStatistic_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    WORD            mFlags;                      /* Bit0=Valid Rx/Tx Counter, Bit1=Valid Error Counter */
    ULONG           mRxPacketCount;
    ULONG           mRxByteCount;
    ULONG           mTxPacketCount;
    ULONG           mTxByteCount;
    ULONG           mCollisionCount;
    ULONG           mErrorCount;
} VBLWlanStatistic;

/*----------------------------------------------------------------------------
|
| AFDX frame object
|
-----------------------------------------------------------------------------*/
/* HINT: Extension of this structure is not allowed! */
typedef struct VBLAfdxFrame_t
{
    VBLObjectHeader mHeader;                     /* object header - NOTE! set the object size to*/
                                                 /* mHeader.mObjectSize = sizeof( VBLEthernetFrame) + mPayLoadLength; */
    BYTE            mSourceAddress[6];
    WORD            mChannel;
    BYTE            mDestinationAddress[6];
    WORD            mDir;                        /* Direction flag: 0=Rx, 1=Tx, 2=TxRq */
    WORD            mType;
    WORD            mTPID;
    WORD            mTCI;
    BYTE 	          mEthChannel;
    WORD	          mAfdxFlags; 
    ULONG	          mBAGusec;
    WORD            mPayLoadLength;              /* Number of valid mPayLoad bytes */
    BYTE*           mPayLoad;                    /* Max 1500 data bytes per frame  */
} VBLAfdxFrame;

/* HINT: this struct might be extended in future versions! */
typedef struct VBLAfdxStatistic_t
{
    VBLObjectHeader mHeader;                     /* object header */
    WORD            mChannel;                    /* application channel */
    WORD            mFlags;                      /* Bit0=Valid Rx/Tx Counter, Bit1=Valid Error Counter; Bit2=Valid VLId */
    ULONG           mRxPacketCount;
    ULONG           mRxByteCount;
    ULONG           mTxPacketCount;
    ULONG           mTxByteCount;
    ULONG           mCollisionCount;
    ULONG           mErrorCount;
    ULONG           mStatDroppedRedundantPacketCount;
    ULONG           mStatRedundantErrorPacketCount;
    ULONG           mStatIntegrityErrorPacketCount;
    ULONG           mStatAvrgPeriodMsec;
    ULONG           mStatAvrgJitterMysec;
    ULONG           mVLId;
    ULONG           mStatDuration;
} VBLAfdxStatistic;

/*----------------------------------------------------------------------------
|
| Application trigger object
|
-----------------------------------------------------------------------------*/

#define BL_TRIGGER_FLAG_SINGLE_TRIGGER 0x00000000 	/* single trigger type */
#define BL_TRIGGER_FLAG_LOGGING_START  0x00000001 	/* start of logging trigger type */
#define BL_TRIGGER_FLAG_LOGGING_STOP   0x00000002 	/* stop of logging trigger type */
/* HINT: Extension of this structure is not allowed! */
typedef struct VBLAppTrigger_t
{
    VBLObjectHeader mHeader;                     /* object header */
    ULONGLONG       mPreTriggerTime;             /* pre-trigger time */
    ULONGLONG       mPostTriggerTime;            /* post-trigger time */
    WORD            mChannel;                    /* channel of event which triggered (if any) */
    WORD            mFlags;                      /* trigger type (see above) */
    DWORD           mAppSecific2;                /* app specific member 2 */
} VBLAppTrigger;

/*----------------------------------------------------------------------------
|
| Application text object
|
-----------------------------------------------------------------------------*/
#define BL_APPTEXT_MEASUREMENTCOMMENT 0x00000000
#define BL_APPTEXT_DBCHANNELINFO      0x00000001

#define APPTEXT_DBCHANNELINFO_VERSION( f) ( BYTE)(   f & 0x000000FF)
#define APPTEXT_DBCHANNELINFO_CHANNEL( f) ( BYTE)( ( f & 0x0000FF00) >> 8)
#define APPTEXT_DBCHANNELINFO_BUSTYPE( f) ( BYTE)( ( f & 0x00FF0000) >> 16)
#define APPTEXT_DBCHANNELINFO_CANFD( f)   ( BYTE)( ( f & 0x01000000) >> 24)
#define APPTEXT_DBCHANNELINFO_FLAGS( version, bustype, channel, canfd) \
    (DWORD)( ( ( DWORD)(canfd   & 0x01) << 24) | \
             ( ( DWORD)(bustype & 0xFF) << 16) | \
             ( ( DWORD)(channel & 0xFF) << 8) | \
             ( ( DWORD)(version & 0xFF)))
/* HINT: Extension of this structure is not allowed! */
typedef struct VBLAppText_t
{
    VBLObjectHeader mHeader;                     /* object header - NOTE! set the object size to*/
                                                 /* */
                                                 /* mHeader.mObjectSize = sizeof( VBLAppText) + mTextLength; */
                                                 /* */
    DWORD           mSource;                     /* source of text */
    DWORD           mReserved;                   /* reserved */    
    DWORD           mTextLength;                 /* text length in bytes */
    LPSTR           mText;                       /* text in MBCS */
} VBLAppText;

/*----------------------------------------------------------------------------
|
| Realtime clock object
|
-----------------------------------------------------------------------------*/
/* HINT: Extension of this structure is not allowed! */
typedef struct VBLRealtimeClock_t
{
    VBLObjectHeader mHeader;                     /* object header */
    ULONGLONG       mTime;                       /* logging start time in ns since 00:00 1.1.1970 GMT */
    ULONGLONG       mLoggingOffset;              /* measurement zero offset in ns to 00:00 1.1.1970 GMT */
} VBLRealtimeClock;

/*----------------------------------------------------------------------------
|
| File statistics
|
-----------------------------------------------------------------------------*/

#define BL_APPID_UNKNOWN      0
#define BL_APPID_CANALYZER    1
#define BL_APPID_CANOE        2
#define BL_APPID_CANSTRESS    3
#define BL_APPID_CANLOG       4
#define BL_APPID_CANAPE       5
#define BL_APPID_CANCASEXLLOG 6

#define BL_COMPRESSION_NONE   0
#define BL_COMPRESSION_SPEED  1
#define BL_COMPRESSION_DEFAULT 6
#define BL_COMPRESSION_MAX    9

typedef struct VBLFileStatistics_t
{
    DWORD     mStatisticsSize;                   /* sizeof (VBLFileStatistics) */
    BYTE      mApplicationID;                    /* application ID */
    BYTE      mApplicationMajor;                 /* application major number */
    BYTE      mApplicationMinor;                 /* application minor number */
    BYTE      mApplicationBuild;                 /* application build number */
    ULONGLONG mFileSize;                         /* file size in bytes */
    ULONGLONG mUncompressedFileSize;             /* uncompressed file size in bytes */
    DWORD     mObjectCount;                      /* number of objects */
    DWORD     mObjectsRead;                      /* number of objects read */
} VBLFileStatistics;

typedef struct VBLFileStatisticsEx_t
{
    DWORD      mStatisticsSize;                   /* sizeof (VBLFileStatisticsEx) */
    BYTE       mApplicationID;                    /* application ID */
    BYTE       mApplicationMajor;                 /* application major number */
    BYTE       mApplicationMinor;                 /* application minor number */
    BYTE       mApplicationBuild;                 /* application build number */
    ULONGLONG  mFileSize;                         /* file size in bytes */
    ULONGLONG  mUncompressedFileSize;             /* uncompressed file size in bytes */
    DWORD      mObjectCount;                      /* number of objects */
    DWORD      mObjectsRead;                      /* number of objects read */
    SYSTEMTIME mMeasurementStartTime;             /* measurement start time */
    SYSTEMTIME mLastObjectTime;                   /* last object time */
    DWORD      mReserved[18];                     /* reserved */
} VBLFileStatisticsEx;


/*----------------------------------------------------------------------------
|
| Bus system independent
|
-----------------------------------------------------------------------------*/

#define BL_BUSTYPE_CAN      1
#define BL_BUSTYPE_LIN      5
#define BL_BUSTYPE_MOST     6
#define BL_BUSTYPE_FLEXRAY  7
#define BL_BUSTYPE_J1708    9
#define BL_BUSTYPE_ETHERNET 10
#define BL_BUSTYPE_WLAN     13
#define BL_BUSTYPE_AFDX     14

typedef struct VBLDriverOverrun_t
{
  VBLObjectHeader mHeader;                     /* object header */
  DWORD           mBusType;                    /* bus type (see BL_BUSTYPE_...) */
  WORD            mChannel;                    /* channel where overrun occured */
  WORD            mDummy;
} VBLDriverOverrun;

/*----------------------------------------------------------------------------
|
| Event Comment
|
-----------------------------------------------------------------------------*/
typedef struct VBLEventComment_t
{
    VBLObjectHeader mHeader;                     /* object header - NOTE! set the object size to*/
    /* */
    /* mHeader.mObjectSize = sizeof( VBLEventComment) + mTextLength; */
    /* */
    DWORD           mCommentedEventType;         /* commented event type */
    DWORD           mTextLength;                 /* text length in bytes */
    LPSTR           mText;                       /* text in MBCS */
} VBLEventComment;

/*----------------------------------------------------------------------------
|
| Event Global Marker
|
-----------------------------------------------------------------------------*/
typedef struct VBLGlobalMarker_t
{
    VBLObjectHeader mHeader;                     /* object header - NOTE! set the object size to*/
    /* */
    /* mHeader.mObjectSize = sizeof( VBLEventComment) + mGroupNameLength + mMarkerNameLength + mDescriptionLength */
    /* */
    DWORD           mCommentedEventType;         /* commented event type */
    COLORREF        mForegroundColor;
    COLORREF        mBackgroundColor;
    BYTE            mIsRelocatable;
    DWORD           mGroupNameLength;            /* group name length in bytes */
    DWORD           mMarkerNameLength;           /* marker name length in bytes */
    DWORD           mDescriptionLength;          /* description length in bytes */
    LPSTR           mGroupName;                  /* group name in MBCS */    
    LPSTR           mMarkerName;                 /* marker name in MBCS */    
    LPSTR           mDescription;                /* description in MBCS */
} VBLGlobalMarker;

/*----------------------------------------------------------------------------
|
| API
|
-----------------------------------------------------------------------------*/

#define BL_FLUSH_STREAM   0x00000001
#define BL_FLUSH_FILE     0x00000002

#if defined ( __cplusplus )
extern "C" {
#endif

struct IBLCallback
{
    enum BLMessageLevel
    {
        eInfo    = 0, // Error
        eWarning = 1, // Warning
        eError   = 2  // Information only
    };

    enum BLMessageType
    {
        eDefault        = 0, // typically in write window
        eSimple         = 1, // typically in message box
        eAskStop        = 2, // typically in message box with question to stop
        eAskStopFurther = 3  // typically in message box with questions to stop or show further errors
    };

    virtual void OutputMessage(BLMessageType messageType, BLMessageLevel messageLevel, LPCSTR lpMessage) = 0;
};

BLAPI( HANDLE) BLCreateFile( LPCSTR lpFileName, DWORD dwDesiredAccess);
BLAPI( HANDLE) BLCreateFileEx( LPCSTR lpFileName, DWORD dwDesiredAccess, LPCSTR lpServer, LPCSTR lpHost);
BLAPI( HANDLE) BLCreateFileEx2( LPCSTR lpFileName, DWORD dwDesiredAccess, LPCSTR lpServer, LPCSTR lpHost, IBLCallback* pCallback);
BLAPI( BOOL)   BLCloseHandle( HANDLE hFile);

BLAPI( BOOL)   BLWriteObject( HANDLE hFile, VBLObjectHeaderBase* pBase);
BLAPI( BOOL)   BLPeekObject( HANDLE hFile, VBLObjectHeaderBase* pBase);
BLAPI( BOOL)   BLSkipObject( HANDLE hFile, VBLObjectHeaderBase* pBase);
BLAPI( BOOL)   BLReadObject( HANDLE hFile, VBLObjectHeaderBase* pBase); /* obsolete - replaced by BLReadObjectSecure */
BLAPI( BOOL)   BLReadObjectSecure( HANDLE hFile, VBLObjectHeaderBase* pBase, size_t expectedSize);
BLAPI( BOOL)   BLFreeObject( HANDLE hFile, VBLObjectHeaderBase* pBase);

BLAPI( BOOL)   BLSetApplication( HANDLE hFile, BYTE appID, BYTE appMajor, BYTE appMinor, BYTE appBuild);
BLAPI( BOOL)   BLSetWriteOptions( HANDLE hFile, DWORD dwCompression, DWORD dwReserved);
BLAPI( BOOL)   BLSetMeasurementStartTime( HANDLE hFile, const LPSYSTEMTIME lpStartTime);
BLAPI( BOOL)   BLGetFileStatistics( HANDLE hFile, VBLFileStatistics* pStatistics);
BLAPI( BOOL)   BLGetFileStatisticsEx( HANDLE hFile, VBLFileStatisticsEx* pStatistics);
BLAPI( BOOL)   BLFlushFileBuffers( HANDLE hFile, DWORD dwFlags);

#if defined ( __cplusplus )
}
#endif

/*----------------------------------------------------------------------------
|
| 
|
-----------------------------------------------------------------------------*/

#if defined ( _MSC_VER )
  #pragma pack( pop)
#elif defined ( __BORLANDC__ )
  #pragma option pop
  #pragma nopushoptwarn
  #pragma nopackwarning
#endif

#endif // BINARY_LOGGING_H
