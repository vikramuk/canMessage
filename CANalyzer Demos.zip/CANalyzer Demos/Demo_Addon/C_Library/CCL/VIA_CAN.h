/*-----------------------------------------------------------------------------
Module: VIA (observed)
Interfaces: This is a public interface header.
-------------------------------------------------------------------------------
External interface for to the CAN bus (for Nodelayer-DLLs)
-------------------------------------------------------------------------------
Copyright (c) Vector Informatik GmbH. All rights reserved.
-----------------------------------------------------------------------------*/

#ifndef VIA_CAN_H
#define VIA_CAN_H

/*-----------------------------------------------------------------------------
Version of the interfaces, which are declared in this header

19.01.2000   1.0  As      Creation
24.01.2000   1.1  As      Handling of Node improved
11.04.2003   1.2  As      Status Handling added (Busoff,ErrorActive,...)
                          Methods 'SetBtr' and 'SetCanCabsMode' added
25.02.2005   1.3  Rue     Method 'GetBtr' added
03.05.2007   1.4  As      SyncPulse added
08.06.2010   1.5  Bgr     Added VIAOnCanMessage2 - EVAL00066511

sometime     2.0          By definition version 2.0 will be the first release 
in the                    of VIA interface, that is not longer compatible with 
future                    version 1.x 
-----------------------------------------------------------------------------*/

#define  VIACANMajorVersion 1
#define  VIACANMinorVersion 5

// ============================================================================
// Dependencies
// ============================================================================

#ifndef VIA_H
#include "VIA.h"
#endif

// ============================================================================
// CAN bus interface
// ============================================================================

//Specifies flags in a CAN-Message
enum VIAFlagsCanMessage
{
  kVIA_Rtr   = 1,  // RTR-Flag within a CAN-Message
  kVIA_Wu    = 2,  // Wakeup (high voltage message on single wire)
  kVIA_Te    = 4,  // transceiver error (two wire lowspeed CAN bus only, one
                   // of the two wires failed, the other is still working)
};

// 
// Callback object to receive a message from the CAN bus 
//
class VIAOnCanMessage
{
public:
  VIASTDDECL OnMessage(VIATime     time,         // timestamp of the message 
                       VIAChannel  channel,      // CAN channel
                       uint8       dir,          // direction of message (see enum VIADir)
                       uint32      id,           // CAN identifier
                       uint32      flags,        // CAN message flags (see enum VIAFlagsCanMessage)
                       uint8       dlc,          // data length code
                       const uint8 data[8]) = 0; // data bytes of the message  
};


#if defined ( VIACANMinorVersion) && ( VIACANMinorVersion >= 5)
// 
// Callback object to receive a message from the CAN bus in extended format
//
class VIAOnCanMessage2
{
public:
  VIASTDDECL OnMessage(VIATime     time,             // timestamp of the message 
                       VIAChannel  channel,          // CAN channel
                       uint8       dir,              // see enum VIADir
                       uint32      id,               // CAN identifier
                       uint32      flags,            // see enum VIAFlagsCanMessage
                       uint8       dlc,              // data length code
                       const uint8 data[8],          // data bytes of the message
                       uint32      frameLength,      // frame length in ns
                       VIATime     startOfFrame,     // start of frame timestamp of the message
                       uint8       isConsecutive)=0; // 1-is consecutive frame, 0-is not a consecutive frame in a burst 
};
#endif
//
// Callback object to receive error frames from the CAN bus  
//
class VIAOnCanErrorFrame
{
public:
   VIASTDDECL OnErrorFrame(VIATime    time,        // timestamp of the message 
                           VIAChannel channel,     // CAN channel
                           uint8      dir,         // direction of message (see enum VIADir)
                           uint8      length,      // length of the frame (Number of bits)
                           uint32     flags ) = 0; // reserved for future use
};


// Specifies the error code for error status messages
enum VIACanErrorCode
{
  kVIA_CanErrorActive   = 1,
  kVIA_CanErrorPassiv   = 2,
  kVIA_CanWarningLimit  = 3,
  kVIA_CanBusOff        = 4,
};

//
// Callback object to receive error status messages from the can controller
// (BufOff, ErrorPassiv, ...)
//
class VIAOnCanError
{
public:
   VIASTDDECL OnError(VIATime    time,         // timestamp of the error status 
                      VIAChannel channel,      // CAN channel
                      uint32     errorCode,    // error code (see enum VIACanErrorCode)
                      uint8      errorCountTx, // Tx error counter of can controller
                      uint8      errorCountRx  // Rx error counter of can controller
                      ) = 0;
};


//Specifies pulse code for sync event
enum VIASyncPulseCode
{
  kVIA_SyncPulseExternal = 0x00,   // sync pulse triggered externally
  kVIA_SyncPulseOur      = 0x01,   // sync pulse triggered by the hardware itself
  kVIA_SyncPulseShared   = 0x02,   
};

//
// Callback object for the sync event
//
class VIAOnSyncPulse
{
public:
  VIASTDDECL OnSyncPulse(VIATime     time,           // timestamp of the error status 
                         VIAChannel  channel,        // CAN channel
                         uint8       pulsecode) = 0; // pulse code of sync event (see enum VIASyncPulseCode)
};


// ============================================================================
// class VIACan
// ============================================================================
class VIACan : public VIABus
{
public:
   // Registration for messages on the CAN bus
   // The Method should be called at 'InitMeasurement' only.
   VIASTDDECL CreateMessageRequest(VIARequestHandle* handle,   // [IN] Created request handle
                                   VIAOnCanMessage* sink,      // [IN] Callback object
                                   uint8      requestType,     // [IN] Request type about message (see enum VIARequestType)
                                   uint32     id,              // [IN] Id
                                   VIAChannel channel,         // [IN] CAN channel
                                   uint32     mask) = 0;       // [IN] (?)

   // Registration for Error Frames on the CAN bus
   // The Method should be called at 'InitMeasurement' only.
   VIASTDDECL CreateErrorFrameRequest(VIARequestHandle* handle,   // [IN] Created request handle
                                      VIAOnCanErrorFrame* sink,   // [IN] Callback object
                                      VIAChannel channel) = 0;    // [IN] CAN channel

   // Releases a Request (MessageRequest or ErrorFrameRequest)
   VIASTDDECL ReleaseRequest (VIARequestHandle handle) = 0;

   // Puts a message on the CAN bus
   VIASTDDECL OutputMessage(VIAChannel  channel,       // [IN] CAN channel
                            uint32      id,            // [IN] CAN identifier
                            uint32      flags,         // [IN] CAN message flags (see enum VIAFlagsCanMessage)
                            uint8       dlc,           // [IN] Data length code
                            const uint8 data[8] ) = 0; // [IN] Data bytes of the message

   // Puts an error frame on the CAN bus
   VIASTDDECL OutputErrorFrame(VIAChannel channel,      // [IN] CAN channel
                               uint8      length,       // [IN] Length of the frame (Number of bits)
                               uint32     flags=0) = 0; // [IN] Reserved for future use

   // I don't know, what the following is doing, but it looks very important and 
   // is used by some of the old nodelayers
   VIASTDDECL InitPortBit      (uint8 bits) = 0;
   VIASTDDECL SetPortBit       (uint8 bits) = 0;
   VIASTDDECL InitCanRxInputs  (uint8 bits) = 0;
   VIASTDDECL SetCanRxInputs   (uint8 bits) = 0;
   VIASTDDECL SetPortBitEx     (uint8 mask, uint8 bits) = 0;
   VIASTDDECL ResetCan         (VIAChannel channel) = 0;
   VIASTDDECL SetCanOcr        (VIAChannel channel, uint8 ocr) = 0;

//
// The following methods are added with Version 1.2 of VIA_CAN
// 

   // Registration for Error Status message (BufOff, ErrorPassiv, ...)
   // The Method should be called at 'InitMeasurement' only.
   VIASTDDECL CreateStatusRequest (VIARequestHandle* handle,  // [IN] Created request handle
                                   VIAOnCanError* sink,       // [IN] Callback object
                                   VIAChannel channel) = 0;   // [IN] CAN channel

   // Sets another baud rate. The values do not become active until the next 
   // call of the method ResetCan().
   // channel:  The CAN channel, where to change the baud rate 
   // btr0:     Value of Bit Timing Register 0
   // btr1:     Value of Bit Timing Register 0
   // Method returns always kVIA_OK
   VIASTDDECL SetBtr(VIAChannel channel, uint8 btr0, uint8 btr1) = 0;

   // Switch the mode of the transceiver (see CAPL function SetCanCabsMode)
   // Method returns kVIA_OK on success or kVIA_ServiceNotRunning, when calling the 
   // method is not allowed.
   VIASTDDECL SetCanCabsMode(VIAChannel channel, int32 type, int32 mode, int32 flags) = 0;
   
#if defined ( VIAMinorVersion) && ( VIAMinorVersion >= 20)
   // Retrieves messages by ID.
   VIASTDDECL GetMessage(unsigned long ID, VIDBMessageDefinition** message) = 0;
   // You should retrieve messages using the ID. Use the name only if the ID is not available.
   VIASTDDECL GetMessage(const char* name, VIDBMessageDefinition** message) = 0;

   // Gets access to attributes of the network / bus itself:
   // Returns the attribute / the attribute type / the numeric value / the string value
   VIDB_DECLARE_ATTRIBUTE_HOLDER

   // Retrieves the definition of an arbitrary node on the bus
   VIASTDDECL GetNodeDefinition(const char* nodeName, VIDBNodeDefinition** nodeDefinition) = 0;
   // Iterates over nodes
   VIDB_DECLARE_ITERATABLE(NodeDefinition)
#endif

   // Returns the currently set baud rate. See also SetBtr.
   // channel:  The CAN channel whose baud rate shall be returned. Wildcard is not allowed.
   // btr0:     Value of Bit Timing Register 0
   // btr1:     Value of Bit Timing Register 1
   // Returns kVIA_OK on success or kVIA_ServiceNotRunning on failure.
   VIASTDDECL GetBtr(VIAChannel channel, uint8* btr0, uint8* btr1) = 0; 

#if defined ( VIAMinorVersion) && ( VIAMinorVersion >= 21)
   // Retrieves J1939 message with specified ID
   VIASTDDECL GetJ1939Message(unsigned long ID, unsigned long flags, VIDBMessageDefinition** message) = 0;
#endif
   
   // Registration for the sync pulse event
   // The method should be called at 'InitMeasurement' only.
   VIASTDDECL CreateSyncPulseRequest (VIARequestHandle* handle,   // [IN] Created request handle
                                      VIAOnSyncPulse* sink,       // [IN] Callback object
                                      VIAChannel channel) = 0;    // [IN] CAN channel


#if defined ( VIACANMinorVersion) && ( VIACANMinorVersion >= 5)
   // Registration for messages on the CAN bus
   // The Method should be called at 'InitMeasurement' only.
   VIASTDDECL CreateMessageRequest2   (VIARequestHandle* handle,   // the created request handle 
                                       VIAOnCanMessage2*  sink,    // callback object 
                                       uint8      requestType,     // see enum VIARequestType
                                       uint32     id,              // (?)           
                                       VIAChannel channel,         // (?)     
                                       uint32     mask) =0;        // (?)
#endif

}; // class VIACanBus


#endif // VIA_CAN_H
