// GlobalEventHandler.c : Example of a CANalyzer/CANoe C Library
//
// This sample file demonstrates general structure of a  
// CANalyzer/CANoe C Library.
//
// The function 'cclOnDllLoad' must be implemented in every 
// CANalyzer/CANoe C Library. In the body of this function additional 
// event handlers (DllUnLoad, MeasurementPreStart, MeasurementStart, 
// MeasurementStop) can be registered.
// 

#include "CCL/CCL.h"


extern void OnDllUnLoad();
extern void OnMeasurementPreStart();
extern void OnMeasurementStart();
extern void OnMeasurementStop();


void cclOnDllLoad()
{
  cclWrite("C Library Example: cclOnDllLoad");
  
  cclSetDllUnloadHandler(&OnDllUnLoad);
  cclSetMeasurementPreStartHandler(&OnMeasurementPreStart);
  cclSetMeasurementStartHandler(&OnMeasurementStart);
  cclSetMeasurementStopHandler(&OnMeasurementStop);
}


void OnDllUnLoad()
{
  cclWrite("C Library Example: OnDllUnLoad");
}


void OnMeasurementPreStart()
{
  cclPrintf("C Library Example: %s", "OnMeasurementPreStart");
}


void OnMeasurementStart()
{
  cclWrite("C Library Example: OnMeasurementStart");
}


void OnMeasurementStop()
{
  cclWrite("C Library Example: OnMeasurementStop");
}
