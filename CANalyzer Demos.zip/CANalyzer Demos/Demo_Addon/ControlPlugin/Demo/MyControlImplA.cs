﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Vector.PanelControlPlugin;
using System.Drawing;
using System.Windows.Forms;
using System.Diagnostics;
using System.ComponentModel;

namespace Demo
{
  // =====>
  // exchange the name of the bitmap
  // the file must be found in the subdirectory "Resources" of the project
  // set Build Action of the bmp-file to "Embedded Resource"
  [ToolboxBitmap(typeof(resxfinder), "Demo.Resources.ToolBox_ControlA.bmp")]
  // <=====
  // =====>
  // rename the source file and the class MyControlImplA in the whole file
  public class MyControlImplA : IPluginPanelControl
  // <=====
  {
    #region Members

    // symbol value for exchanging the value between CANoe and plugin control and vice versa
    IExchangeSymbolValue mSymbolValue = null;
    
    // =====>
    // replace the class name "MyUserControl" by the class name of the control, which shall be used in the paneldesigner
    MyUserControl mMyUserControl = new MyUserControl();  // control, which actually is shown in the panel
    // <=====

    #endregion

    #region construction
    
    /// <summary>
    /// Constructor.
    /// </summary>
    public MyControlImplA()
    {
    }

    #endregion

    #region IPluginPanelControl Members

    /// <summary>
    /// This method is called, when the panel is loaded in CANoe/CANalyzer.
    /// </summary>
    /// <param name="value">Object, which is used to transmit a symbol value during the measurement. </param>
    public void Initialize(IExchangeSymbolValue value)
    {
      // remember the symbol value object to be able to receive a value in the plugin control 
      // and send a value from the plugin control
      mSymbolValue = value;

      // assign an event handler for receiving values from CANoe
      mSymbolValue.ValueChanged += OnRxValue;

      // =====> ONLY FOR TX: necessary only, if plugin control shall send values
      // Assign an event handler for sending a value from the plugin control.
      // If the plugin control only receives values, this is not necessary.
      mMyUserControl.ValueChanged += new MyUserControl.ValueChangedEventHandler(OnTxValue);
      // <=====
    }

    /// <summary>
    /// Returns the name of the plugin control, which is shown in the toolbox of the panel designer.
    /// </summary>
    public string ControlName
    {
      get 
      {
        // =====>
        return "MyControlA"; 
        // <=====
      }
    }

    /// <summary>
    /// Returns the control, which actually shall be shown in the panel.
    /// </summary>
    public System.Windows.Forms.Control ExternalControl
    {
      get 
      { 
        return mMyUserControl; 
      }
    }

    /// <summary>
    /// This property is for exchanging the symbol value.
    /// </summary>
    public IExchangeSymbolValue SymbolValue
    {
      get
      {
        return mSymbolValue;
      }
      set
      {
        mSymbolValue = value;
      }
    }

    /// <summary>
    /// Returns the list of property names, which are supported by the uplugin  control, i.e.
    /// the list of properties, which can be configured in the property grid of the 
    /// panel designer.
    /// </summary>
    public IList<string> SupportedProperties
    {
      get 
      {
        List<string> supportedProperties = new List<string>();

        // =====>
        supportedProperties.Add("MyTitle");
        supportedProperties.Add("MyBorderStyle");
        // <=====

        return supportedProperties;
      }
    }

    /// <summary>
    /// Returns true, if the plugin control can change the background color, otherwise false.
    /// </summary>
    public bool SupportsPropertyBackColor
    {
      get 
      {
        // =====>
        // return false, if the plugin control does not support changing the background color
        return true;
        // <=====
      }
    }

    /// <summary>
    /// Returns true, if the plugin control can change the foreground color, otherwise false.
    /// </summary>
    public bool SupportsPropertyForeColor
    {
      get 
      {
        // =====>
        // return false, if the plugin control does not support changing the foreground color
        return true; 
        // <=====
      }
    }

    /// <summary>
    /// Property to set or get the background color of the plugin control.
    /// This method can called via CAPL, to control the display of controls.
    /// Provide a dummy implementation (do nothing), if the plugin control cannot change its background color.
    /// </summary>
    public Color ControlBackColor
    {
      // =====>
      // dummy implementation, if the plugin control does not support changing the background color:
      // get; set;
      // otherwise:
      get
      {
        return mMyUserControl.BackColor;
      }
      set
      {
        mMyUserControl.BackColor = value;
      }
      // <=====
    }

    /// <summary>
    /// Property to set or get the foreground color of the plugin control.
    /// This method can called via CAPL, to control the display of controls.
    /// Provide a dummy implementation (do nothing), if the plugin control cannot change its foreground color.
    /// </summary>
    public Color ControlForeColor
    {
      // =====>
      // dummy implementation, if the plugin control does not support changing the foreground color:
      // get; set;
      // otherwise:
      get
      {
        return mMyUserControl.ForeColor;
      }
      set
      {
        mMyUserControl.ForeColor = value;
      }
      // <=====
    }

    /// <summary>
    /// Property to enable or disable the plugin control.
    /// This property is called, when the DisplayOnly-property is set in the property grid of the panel designer.
    /// This method can called via CAPL, to control the display/behavior of controls.
    /// </summary>
    public bool Enabled
    {
      get
      {
        return ExternalControl.Enabled;
      }
      set
      {
        ExternalControl.Enabled = value;
      }
    }

    /// <summary>
    /// Property to set the plugin control visible or invisible.
    /// This method can called via CAPL, to control the display of controls.
    /// </summary>
    public bool Visible
    {
      get
      {
        return ExternalControl.Visible;
      }
      set
      {
        ExternalControl.Visible = value;
      }
    }

    /// <summary>
    /// Serializes all supported properties and returns the serialization string in the out parameter.
    /// </summary>
    /// <param name="serializationString">serialized properties</param>
    /// <returns>true, if serialization was successful, otherwise false</returns>
    public bool SerializeSupportedProperties(out string serializationString)
    {
      bool ok = true;
      serializationString = "";

      // =====>
      // provide a serialization for all properties supported by the plugin control
      // (without the properties ControlBackColor, ControlForeColor, Enabled and Visible)
      // the following examples show two different possibilities:
      // 1st: for a simple string property
      // 2nd: for a property, which has a TypeConverter
      // Take care, that the deserialization is implemented accordingly.

      // property "MyTitle"
      serializationString += MyTitle.ToString();
      serializationString += ";";

      // property "MyBorderStyle"
      TypeConverter tc = TypeDescriptor.GetConverter(MyBorderStyle);
      if (tc.CanConvertTo(typeof(string)))
      {
        object stringVal = tc.ConvertTo(MyBorderStyle, typeof(string));
        serializationString += stringVal.ToString();
        serializationString += ";";
      }
      else
      {
        ok = false;
      }
      // <=====

      return ok;
    }

    /// <summary>
    /// Deserializes the supported properties from the given string.
    /// </summary>
    /// <param name="serializationString">serialized properties</param>
    /// <returns>true, if deserialization was successful, otherwise false</returns>
    public bool DeserializeSupportedProperties(string serializationString)
    {
      bool retVal = true;

      // =====>
      // provide a serialization for all properties supported by the plugin control
      // (without the properties ControlBackColor, ControlForeColor, Enabled and Visible)
      // the following examples show two different possibilities 
      // 1st: for a simple string property
      // 2nd: for a property, which has a TypeConverter
      // Take care, that the serialization is implemented accordingly.

      string[] propertyValues = serializationString.Split(new char[] { ';' });

      if (propertyValues.Count() > 0)
      {
        MyTitle = propertyValues[0];
      }

      if (propertyValues.Count() > 1)
      {
        object valueObject = null;
        TypeConverter tc = TypeDescriptor.GetConverter(MyBorderStyle.GetType());
        if (tc.CanConvertFrom(typeof(string)))
        {
          try
          {
            valueObject = tc.ConvertFrom(propertyValues[1]);
            MyBorderStyle = (BorderStyle)valueObject;
          }
          catch (Exception)
          {
            MyBorderStyle = BorderStyle.None;
          }
        }
      }
      // <=====

      return retVal;
    }

    #endregion

    #region supported properties

    // =====>
    // implement all properties of the plugin control, which shall be configured in the 
    // property grid of the paneldesigner

    [CategoryAttribute("MyControl Settings ")]
    [DisplayName("My Title")]
    public string MyTitle
    {
      get
      {
        return mMyUserControl.Title;
      }
      set
      {
        mMyUserControl.Title = value;
      }
    }

    [CategoryAttribute("MyControl Settings ")]
    [DisplayName("Border Style")]
    public BorderStyle MyBorderStyle
    {
      get
      {
        return mMyUserControl.MyBorderStyle;
      }
      set
      {
        mMyUserControl.MyBorderStyle = value;
      }
    }

    // <=====

    #endregion

    #region Rx/Tx values

    /// <summary>
    /// Actions which are necessary, when a new value is received from CANoe.
    /// The received value is in this-value and must be sent to the plugin control.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    void OnRxValue(object sender, EventArgs e)
    {
      // =====>
      // this line may be obsolete, if the plugin control only displays values but does not change them
      mMyUserControl.ValueChanged -= OnTxValue;
      // <=====
      try
      {
        // Value.SymbolDataType depends on the symbol data type of the assigned symbol
        // It is given from the CANoe database and must not be changed.
          switch (SymbolValue.SymbolDataType)
        {
          case ExchangeSymbolDataType.Long:
            // =====>
            // display Value.LongValue in the plugin control
                mMyUserControl.OnRxValue(SymbolValue.LongValue);
            // <=====
            break;
          case ExchangeSymbolDataType.Double:
            // =====>
            // display Value.DoubleValue in the plugin control
            mMyUserControl.OnRxValue(SymbolValue.DoubleValue);
            // <=====
            break;
          default:
            break;
        }
      }
      catch (System.Exception)
      {
      }
      // =====>
      // this line may be obsolete, if the plugin control only displays values but does not change them
      mMyUserControl.ValueChanged += OnTxValue;
      // <=====
    }

    // =====> ONLY FOR TX: necessary only, if plugin control shall send values
    /// <summary>
    /// Actions which are necessary, when a new value shall be sent to CANoe.
    /// The sent value must be written to this.Value.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e">ValueChangedEventArgs containing the value to be sent</param>
    void OnTxValue(object sender, ValueChangedEventArgs e)
    {
      try
      {
        if (mSymbolValue == null || 
            mSymbolValue.SymbolDataType == ExchangeSymbolDataType.Unknown)
          return;

        // Value.SymbolDataType depends on the symbol data type of the assigned symbol
        // It is given from the CANoe database and must not be changed.
        switch (mSymbolValue.SymbolDataType)
        {
          case ExchangeSymbolDataType.Long:
            // =====>
            // put the value from the plugin control to Value.LongValue
            mSymbolValue.LongValue = Convert.ToInt32(e.mValue);
            // <=====
            break;
          case ExchangeSymbolDataType.Double:
            // =====>
            // put the value from the plugin control to Value.DoubleValue
            mSymbolValue.DoubleValue = e.mValue;
            // <=====
            break;
          default:
            break;
        }
      }
      catch (System.Exception)
      {
        // make sure, that no exceptions are passed
      }
    }
    // <=====

    #endregion
  }
}

public class resxfinder
{
  //  This is a dirty workaround for a bug in 'GetImageFromResource'.
  //  Use the type of this this class in the 'ToolboxBitmap' Attribute and 
  //  NOT the Control class. The second parameter is the bmp name with 
  //  the DEFAULT(!) namespace of the assembly (see project settings) and the relative directory
  //  where the bitmap can be found.
  //  Class 'resxfinder' must be within this assembly. 
  //  See also: http://www.bobpowell.net/toolboxbitmap.htm
  //  Example:
  //  Default namespace: "Demo"
  //  directory: Resources
  //  Bitmap name: "ToolBox_ControlA.bmp"
  //  Attribute:
  //  [ToolboxBitmap(typeof(resxfinder), "Demo.Resources.ToolBox_ControlA.bmp")]
}
