﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Demo
{
  public partial class MyUserControl : UserControl
  {
    public delegate void ValueChangedEventHandler(object sender, ValueChangedEventArgs e);
    public event ValueChangedEventHandler ValueChanged;

    public MyUserControl()
    {
      InitializeComponent();
    }

    public string Title
    {
      get
      {
        return groupBox1.Text;
      }
      set
      {
        groupBox1.Text = value;
      }
    }

    public BorderStyle MyBorderStyle
    {
      get
      {
        return this.BorderStyle;
      }
      set
      {
        this.BorderStyle = value;
      }
    }

    internal void OnRxValue(double value)
    {
      textBox1.Text = value.ToString(String.Format("F2"));
      textBox2.Text = value.ToString("F0");
    }

    private void btnSend_Click(object sender, EventArgs e)
    {
      if (ValueChanged != null)
      {
        double value = 0;
        if (Double.TryParse(textBox1.Text, out value))
          ValueChanged(sender, new ValueChangedEventArgs(value));
      }
    }
  }

  public class ValueChangedEventArgs : EventArgs
  {
    public ValueChangedEventArgs(double value)
    {
      mValue = value;
    }

    public readonly double mValue = 0;
  }
}
