using System;
using System.Collections;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Windows.Forms;

namespace CSharpPanels
{
	public class CSharpDisplay : System.Windows.Forms.UserControl
	{
        // Declare types
        private CANalyzer.Application App;
        private CANalyzer.Measurement Measurement;
        private System.Windows.Forms.Label lblDiscrete;
        private System.Windows.Forms.Label lblSine;
        private System.Windows.Forms.Label lblLine;
        private System.Windows.Forms.Label lblCuve;
        private System.Windows.Forms.Label lblDispCurve;
        private System.Windows.Forms.Timer tmrSignals;
        private System.Windows.Forms.Label lblDispDiscrete;
        private System.Windows.Forms.Label lblDispLine;
        private System.Windows.Forms.Label lblDispSine;
        private System.Windows.Forms.Label lblCaption;
        private System.ComponentModel.IContainer components;

		public CSharpDisplay()
		{
			// This call is required by the Windows.Forms Form Designer.
			InitializeComponent();

			// Initialize types
            App         = new CANalyzer.Application();
            Measurement = (CANalyzer.Measurement)App.Measurement;
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if( components != null )
					components.Dispose();
			}
			base.Dispose( disposing );
		}

		#region Component Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify 
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
      this.components = new System.ComponentModel.Container();
      this.lblCaption = new System.Windows.Forms.Label();
      this.lblDiscrete = new System.Windows.Forms.Label();
      this.lblSine = new System.Windows.Forms.Label();
      this.lblLine = new System.Windows.Forms.Label();
      this.lblCuve = new System.Windows.Forms.Label();
      this.lblDispCurve = new System.Windows.Forms.Label();
      this.lblDispDiscrete = new System.Windows.Forms.Label();
      this.lblDispLine = new System.Windows.Forms.Label();
      this.lblDispSine = new System.Windows.Forms.Label();
      this.tmrSignals = new System.Windows.Forms.Timer(this.components);
      this.SuspendLayout();
      // 
      // lblCaption
      // 
      this.lblCaption.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblCaption.Location = new System.Drawing.Point(0, 0);
      this.lblCaption.Name = "lblCaption";
      this.lblCaption.Size = new System.Drawing.Size(192, 24);
      this.lblCaption.TabIndex = 0;
      this.lblCaption.Text = "C# Display";
      this.lblCaption.TextAlign = System.Drawing.ContentAlignment.TopCenter;
      // 
      // lblDiscrete
      // 
      this.lblDiscrete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblDiscrete.Location = new System.Drawing.Point(8, 46);
      this.lblDiscrete.Name = "lblDiscrete";
      this.lblDiscrete.Size = new System.Drawing.Size(64, 16);
      this.lblDiscrete.TabIndex = 1;
      this.lblDiscrete.Text = "Discrete:";
      // 
      // lblSine
      // 
      this.lblSine.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblSine.Location = new System.Drawing.Point(8, 94);
      this.lblSine.Name = "lblSine";
      this.lblSine.Size = new System.Drawing.Size(64, 16);
      this.lblSine.TabIndex = 2;
      this.lblSine.Text = "Sine:";
      // 
      // lblLine
      // 
      this.lblLine.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblLine.Location = new System.Drawing.Point(8, 70);
      this.lblLine.Name = "lblLine";
      this.lblLine.Size = new System.Drawing.Size(64, 16);
      this.lblLine.TabIndex = 3;
      this.lblLine.Text = "Line:";
      // 
      // lblCuve
      // 
      this.lblCuve.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblCuve.Location = new System.Drawing.Point(8, 22);
      this.lblCuve.Name = "lblCuve";
      this.lblCuve.Size = new System.Drawing.Size(64, 16);
      this.lblCuve.TabIndex = 4;
      this.lblCuve.Text = "Curve:";
      // 
      // lblDispCurve
      // 
      this.lblDispCurve.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblDispCurve.Location = new System.Drawing.Point(64, 22);
      this.lblDispCurve.Name = "lblDispCurve";
      this.lblDispCurve.Size = new System.Drawing.Size(120, 16);
      this.lblDispCurve.TabIndex = 5;
      this.lblDispCurve.Text = "0";
      this.lblDispCurve.TextAlign = System.Drawing.ContentAlignment.TopRight;
      // 
      // lblDispDiscrete
      // 
      this.lblDispDiscrete.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblDispDiscrete.Location = new System.Drawing.Point(64, 46);
      this.lblDispDiscrete.Name = "lblDispDiscrete";
      this.lblDispDiscrete.Size = new System.Drawing.Size(120, 16);
      this.lblDispDiscrete.TabIndex = 6;
      this.lblDispDiscrete.Text = "0";
      this.lblDispDiscrete.TextAlign = System.Drawing.ContentAlignment.TopRight;
      // 
      // lblDispLine
      // 
      this.lblDispLine.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblDispLine.Location = new System.Drawing.Point(64, 70);
      this.lblDispLine.Name = "lblDispLine";
      this.lblDispLine.Size = new System.Drawing.Size(120, 16);
      this.lblDispLine.TabIndex = 7;
      this.lblDispLine.Text = "0";
      this.lblDispLine.TextAlign = System.Drawing.ContentAlignment.TopRight;
      // 
      // lblDispSine
      // 
      this.lblDispSine.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
      this.lblDispSine.Location = new System.Drawing.Point(64, 94);
      this.lblDispSine.Name = "lblDispSine";
      this.lblDispSine.Size = new System.Drawing.Size(120, 16);
      this.lblDispSine.TabIndex = 8;
      this.lblDispSine.Text = "0";
      this.lblDispSine.TextAlign = System.Drawing.ContentAlignment.TopRight;
      // 
      // tmrSignals
      // 
      this.tmrSignals.Enabled = true;
      this.tmrSignals.Tick += new System.EventHandler(this.tmrSignals_Tick);
      // 
      // CSharpDisplay
      // 
      this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
      this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
      this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(231)))), ((int)(((byte)(231)))), ((int)(((byte)(231)))));
      this.Controls.Add(this.lblDispSine);
      this.Controls.Add(this.lblDispLine);
      this.Controls.Add(this.lblDispDiscrete);
      this.Controls.Add(this.lblDispCurve);
      this.Controls.Add(this.lblCuve);
      this.Controls.Add(this.lblLine);
      this.Controls.Add(this.lblSine);
      this.Controls.Add(this.lblDiscrete);
      this.Controls.Add(this.lblCaption);
      this.Name = "CSharpDisplay";
      this.Size = new System.Drawing.Size(190, 115);
      this.ResumeLayout(false);

        }
		#endregion

        private void tmrSignals_Tick(object sender, System.EventArgs e)
        {
            // get all the signal values and actualize controls
            if(Measurement.Running)
            {
                CANalyzer.Bus bus;
                CANalyzer.Signal signal;
                try
                {
                    bus = (CANalyzer.Bus)App.get_Bus("CAN");
                    signal = (CANalyzer.Signal)bus.GetSignal(1, "MsgCurve", "Curve");
                    lblDispCurve.Text = signal.Value.ToString();

                    signal = (CANalyzer.Signal)bus.GetSignal(1, "MsgDiscrete", "Discrete");
                    lblDispDiscrete.Text = signal.Value.ToString();

                    signal = (CANalyzer.Signal)bus.GetSignal(1, "MsgLine", "Line");
                    lblDispLine.Text = signal.Value.ToString();

                    signal = (CANalyzer.Signal)bus.GetSignal(1, "MsgSine", "Sine");
                    lblDispSine.Text = signal.Value.ToString();
                }
                catch
                {
                }
                finally
                {
                    bus = null;
                    signal = null;
                }
            }
        }
	}
}
