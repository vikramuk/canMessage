Public Class VBNetDisplay
    Inherits System.Windows.Forms.UserControl

    ' Declare types
    Dim WithEvents App As CANalyzer.Application
    Dim WithEvents Measurement As CANalyzer.Measurement

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Initialize types
        App = New CANalyzer.Application
        Measurement = App.Measurement

    End Sub

#Region " Windows Form Designer generated code "

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    Friend WithEvents lblDiscrete As System.Windows.Forms.Label
    Friend WithEvents lblSine As System.Windows.Forms.Label
    Friend WithEvents lblLine As System.Windows.Forms.Label
    Friend WithEvents lblCuve As System.Windows.Forms.Label
    Friend WithEvents lblDispCurve As System.Windows.Forms.Label
    Friend WithEvents tmrSignals As System.Windows.Forms.Timer
    Friend WithEvents lblDispDiscrete As System.Windows.Forms.Label
    Friend WithEvents lblDispLine As System.Windows.Forms.Label
    Friend WithEvents lblDispSine As System.Windows.Forms.Label
    Friend WithEvents lblCaption As System.Windows.Forms.Label

    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
Me.components = New System.ComponentModel.Container
Me.lblCaption = New System.Windows.Forms.Label
Me.lblDiscrete = New System.Windows.Forms.Label
Me.lblSine = New System.Windows.Forms.Label
Me.lblLine = New System.Windows.Forms.Label
Me.lblCuve = New System.Windows.Forms.Label
Me.lblDispCurve = New System.Windows.Forms.Label
Me.lblDispDiscrete = New System.Windows.Forms.Label
Me.lblDispLine = New System.Windows.Forms.Label
Me.lblDispSine = New System.Windows.Forms.Label
Me.tmrSignals = New System.Windows.Forms.Timer(Me.components)
Me.SuspendLayout()
'
'lblCaption
'
Me.lblCaption.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.lblCaption.Location = New System.Drawing.Point(0, 0)
Me.lblCaption.Name = "lblCaption"
Me.lblCaption.Size = New System.Drawing.Size(192, 24)
Me.lblCaption.TabIndex = 0
Me.lblCaption.Text = "VB.NET Display"
Me.lblCaption.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
'
'lblDiscrete
'
Me.lblDiscrete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.lblDiscrete.Location = New System.Drawing.Point(8, 46)
Me.lblDiscrete.Name = "lblDiscrete"
Me.lblDiscrete.Size = New System.Drawing.Size(64, 16)
Me.lblDiscrete.TabIndex = 1
Me.lblDiscrete.Text = "Discrete:"
'
'lblSine
'
Me.lblSine.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.lblSine.Location = New System.Drawing.Point(8, 94)
Me.lblSine.Name = "lblSine"
Me.lblSine.Size = New System.Drawing.Size(64, 16)
Me.lblSine.TabIndex = 2
Me.lblSine.Text = "Sine:"
'
'lblLine
'
Me.lblLine.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.lblLine.Location = New System.Drawing.Point(8, 70)
Me.lblLine.Name = "lblLine"
Me.lblLine.Size = New System.Drawing.Size(64, 16)
Me.lblLine.TabIndex = 3
Me.lblLine.Text = "Line:"
'
'lblCuve
'
Me.lblCuve.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.lblCuve.Location = New System.Drawing.Point(8, 22)
Me.lblCuve.Name = "lblCuve"
Me.lblCuve.Size = New System.Drawing.Size(64, 16)
Me.lblCuve.TabIndex = 4
Me.lblCuve.Text = "Curve:"
'
'lblDispCurve
'
Me.lblDispCurve.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.lblDispCurve.Location = New System.Drawing.Point(64, 22)
Me.lblDispCurve.Name = "lblDispCurve"
Me.lblDispCurve.Size = New System.Drawing.Size(120, 16)
Me.lblDispCurve.TabIndex = 5
Me.lblDispCurve.Text = "0"
Me.lblDispCurve.TextAlign = System.Drawing.ContentAlignment.TopRight
'
'lblDispDiscrete
'
Me.lblDispDiscrete.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.lblDispDiscrete.Location = New System.Drawing.Point(64, 46)
Me.lblDispDiscrete.Name = "lblDispDiscrete"
Me.lblDispDiscrete.Size = New System.Drawing.Size(120, 16)
Me.lblDispDiscrete.TabIndex = 6
Me.lblDispDiscrete.Text = "0"
Me.lblDispDiscrete.TextAlign = System.Drawing.ContentAlignment.TopRight
'
'lblDispLine
'
Me.lblDispLine.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.lblDispLine.Location = New System.Drawing.Point(64, 70)
Me.lblDispLine.Name = "lblDispLine"
Me.lblDispLine.Size = New System.Drawing.Size(120, 16)
Me.lblDispLine.TabIndex = 7
Me.lblDispLine.Text = "0"
Me.lblDispLine.TextAlign = System.Drawing.ContentAlignment.TopRight
'
'lblDispSine
'
Me.lblDispSine.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
Me.lblDispSine.Location = New System.Drawing.Point(64, 94)
Me.lblDispSine.Name = "lblDispSine"
Me.lblDispSine.Size = New System.Drawing.Size(120, 16)
Me.lblDispSine.TabIndex = 8
Me.lblDispSine.Text = "0"
Me.lblDispSine.TextAlign = System.Drawing.ContentAlignment.TopRight
'
'tmrSignals
'
Me.tmrSignals.Enabled = True
'
'VBNetDisplay
'
Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer), CType(CType(231, Byte), Integer))
Me.Controls.Add(Me.lblDispSine)
Me.Controls.Add(Me.lblDispLine)
Me.Controls.Add(Me.lblDispDiscrete)
Me.Controls.Add(Me.lblDispCurve)
Me.Controls.Add(Me.lblCuve)
Me.Controls.Add(Me.lblLine)
Me.Controls.Add(Me.lblSine)
Me.Controls.Add(Me.lblDiscrete)
Me.Controls.Add(Me.lblCaption)
Me.Name = "VBNetDisplay"
Me.Size = New System.Drawing.Size(190, 115)
Me.ResumeLayout(False)

End Sub

#End Region

    Private Sub tmrSignals_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrSignals.Tick

        ' get all the signal values and actualize controls
        If Measurement.Running = True Then

            Dim bus As CANalyzer.Bus
            Dim signal As CANalyzer.Signal

            Try
                bus = App.Bus
                signal = bus.GetSignal(1, "MsgCurve", "Curve")
                lblDispCurve.Text = signal.Value

                signal = bus.GetSignal(1, "MsgDiscrete", "Discrete")
                lblDispDiscrete.Text = signal.Value

                signal = bus.GetSignal(1, "MsgLine", "Line")
                lblDispLine.Text = signal.Value

                signal = bus.GetSignal(1, "MsgSine", "Sine")
                lblDispSine.Text = signal.Value
            Catch
            Finally
                bus = Nothing
                signal = Nothing
            End Try

        End If
    End Sub
End Class
