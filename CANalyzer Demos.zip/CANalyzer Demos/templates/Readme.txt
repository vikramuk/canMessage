Vorlagen f�r Konfigurationen und Datenbasen
===========================================

Dies Verzeichnis enth�lt die folgenden Vorlagen:

1. Konfigurationsvorlagen f�r Bussysteme und Protokolle
-------------------------------------------------------
In diesen Vorlegen (*.TCW sind Vorlagen f�r CANalyzer, *.TCN f�r CANoe) sind bestimmte 
Bussystemeinstellungen (Bussystem und Hardwareeinstellung) bereits eingestellt. 
Der Zugriff auf diese Vorlagen erfolgt �ber den Men�punkt �Konfiguration|Neu� in CANoe oder CANalyzer. 
Beliebige Konfigurationen k�nnen als benutzerdefinierte Vorlagen in dieses Verzeichnis gespeichert werden.

2. Datenbasenvorlagen f�r Bussysteme, Protokolle und Modelgeneratoren
---------------------------------------------------------------------
In diesen Vorlagen (*.DBC) sind verschiedene Bussystem, Protokolle oder Generierungs-Attribute 
vorkonfiguriert. Dadurch werden die unterschiedlichen Modellgeneratoren (z. B. CAPL Generator, Vector IL) 
einfach unterst�tzt.

Zus�tzliche Informationen zu den unterschiedlichen Vorlagen finden sich in der Online-Hilfe




Templates for configurations and databases
==========================================

This folder contains the following templates:

1. Configuration templates for bus systems and protocols
--------------------------------------------------------
Special bus system settings (bus system and hardware configuration) are already defined 
in these templates (*.TCW are templates for CANalyzer, *.TCN for CANoe). Access to the templates 
is done with the menu entry �Configuration|New� in CANoe or CANalyzer. Any configuration 
can be saved to this folder as user defined templates.

2. Databases for bus systems, protocols and model generators
------------------------------------------------------------
In these templates (*.DBC) special bus systems, protocols or attributes for model generators 
are predefined. The different model generators (e. g. CAPL generator, Vector IL) are easily supported.

Additional information about the different templates can be found in the help system.
